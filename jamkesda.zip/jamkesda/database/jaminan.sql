-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2016 at 12:05 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jaminan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_biaya`
--

CREATE TABLE `tbl_biaya` (
  `id_biaya` int(5) NOT NULL,
  `id_hospital` varchar(20) DEFAULT NULL,
  `no_jaminan` varchar(25) DEFAULT NULL,
  `tgl_selesai` date DEFAULT NULL,
  `kwitansi` varchar(100) DEFAULT NULL,
  `total_biaya` float NOT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_biaya`
--

INSERT INTO `tbl_biaya` (`id_biaya`, `id_hospital`, `no_jaminan`, `tgl_selesai`, `kwitansi`, `total_biaya`, `status`) VALUES
(1, 'RS001', 'P0005/V/Promkes-SDK/2016', '2016-05-05', 'http://localhost/jamkesda/file_upload/19925cbc242c7625391b4549f66fad06.jpg', 750000, 'claimed'),
(2, 'RS001', 'P0006/V/Promkes-SDK/2016', '2016-04-01', 'http://localhost/jamkesda/file_upload/7982fddb5d9c682914d719705326dfc2.jpg', 2500000, 'claimed'),
(3, 'RS001', 'P0001/V/Promkes-SDK/2016', '2016-04-08', 'http://localhost/jamkesda/file_upload/5537b8e4e23e82c817504c45893d59b9.jpg', 3000000, 'claimed'),
(4, 'RS001', 'P0010/V/Promkes-SDK/2016', '2016-05-05', 'http://localhost/jamkesda/file_upload/f6f0bdd3fc399bd66df3cefc0e898ed5.jpg', 500000, 'claimed'),
(5, 'RS001', 'P0009/V/Promkes-SDK/2016', '2016-05-08', 'http://localhost/jamkesda/file_upload/096af99d06f22148b13069e5a1c9d508.jpg', 6000000, 'claimed'),
(6, 'RS001', 'P0007/V/Promkes-SDK/2016', '2016-05-23', 'http://localhost/jamkesda/file_upload/592e9012225d4fa1012f4db440f9cc27.jpg', 2000000, 'claimed'),
(7, 'RS001', 'P0003/V/Promkes-SDK/2016', '2016-05-09', 'http://localhost/jamkesda/file_upload/ae814a04a3654bf8b2586af092b155f7.jpg', 7000000, 'claimed'),
(8, 'RS001', 'P0002/V/Promkes-SDK/2016', '2016-05-23', 'http://localhost/jamkesda/file_upload/47a9253557d566fa807d515e119c27dd.jpg', 10000000, 'claimed'),
(9, 'RS002', 'P0008/V/Promkes-SDK/2016', '2016-05-20', 'http://localhost/jamkesda/file_upload/bd9b72e89c7ab1fa6c4a0054744026c4.jpg', 5430000, 'claimed'),
(10, 'RS001', 'P0011/VI/Promkes-SDK/2016', '2016-06-02', 'http://localhost/jamkesda/file_upload/ad764b21bcf2be2fce8cd7831ab07c62.jpg', 5500000, 'claimed'),
(11, 'RS001', 'P0012/VI/Promkes-SDK/2016', '2016-06-03', 'http://localhost/jamkesda/file_upload/c9b1873ded5c8f15c814821f6fad7175.jpg', 417000, 'claimed'),
(12, 'RS002', 'P0004/VI/Promkes-SDK/2016', '2016-06-08', 'http://localhost/jamkesda/file_upload/b9caf36ac8601a72bfeeefd8fceeac39.jpg', 417000, 'claimed'),
(13, 'RS002', 'P0013/VI/Promkes-SDK/2016', '2016-06-08', 'http://localhost/jamkesda/file_upload/e0c0f2f5543ea8b3a84e2ab8332f8dd2.jpg', 7000000, 'claimed'),
(14, 'RS002', 'P0014/VI/Promkes-SDK/2016', '2016-06-10', 'http://localhost/jamkesda/file_upload/d437708e6b6f14b8c13d5dcfd9da7812.jpg', 417000, 'claimed'),
(15, 'RS004', 'P0015/VI/Promkes-SDK/2016', '2016-06-30', 'http://localhost/jamkesda/file_upload/d9159235bf72141a4553fd7c325de4da.jpg', 417000, 'claimed');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_desa`
--

CREATE TABLE `tbl_desa` (
  `id_desa` int(5) NOT NULL,
  `desa` varchar(50) DEFAULT NULL,
  `id_kecamatan` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_desa`
--

INSERT INTO `tbl_desa` (`id_desa`, `desa`, `id_kecamatan`) VALUES
(1, 'Bojong Gede', 1),
(2, 'Cimanggis', 1),
(3, 'Waringin Jaya', 1),
(4, 'Kedung Waringin', 1),
(5, 'Susukan', 1),
(6, 'Bojong Baru', 1),
(7, 'Rawa Panjang', 1),
(8, 'Pabuaran', 1),
(9, 'Ragajaya', 1),
(10, 'Kalong Dua', 2),
(11, 'Kalong Satu', 2),
(12, 'Sadeng', 2),
(13, 'Sibanteng', 2),
(14, 'Babakan Sadeng', 2),
(15, 'Leuwisadeng', 2),
(16, 'Sadeng Kolot', 2),
(17, 'Wangun Jaya', 2),
(18, 'Sukajaya', 4),
(19, 'Sukanegara', 4),
(20, 'Cibodas', 4),
(21, 'Singasari', 4),
(22, 'Sukasima', 4),
(23, 'Singajaya', 4),
(24, 'Balekembang', 4),
(25, 'Bendungan', 4),
(26, 'Sirnagalih', 4),
(27, 'Jonggol', 4),
(28, 'Sukamaju', 4),
(29, 'Sukamanah', 4),
(30, 'Weninggalih', 4),
(31, 'Sukagalih', 4),
(32, 'Karya Mekar', 5),
(33, 'Rantar Kuning', 5),
(34, 'Cikutanahi', 5),
(35, 'Cibatu Taga', 5),
(36, 'Mekarwangi', 5),
(37, 'Tegal Panjang', 5),
(38, 'Cariu', 5),
(39, 'Kuta Mekar', 5),
(40, 'Sukajadi', 5),
(41, 'Babakan Raden', 5),
(42, 'Karadenan', 9),
(43, 'Nenggewer', 9),
(44, 'Nenggewer Mekar', 9),
(45, 'Cibinong', 9),
(46, 'Pekansari', 9),
(47, 'Cirimekar', 9),
(48, 'Sukahati', 9),
(49, 'Tengah', 9),
(50, 'Pondok Rajeg', 9),
(51, 'Harapan Jaya', 9),
(52, 'Ciriung', 9),
(53, 'Pabuaran', 9),
(54, 'Cileungsi', 21),
(55, 'Citapen', 21),
(56, 'Cibedug', 21),
(57, 'Bojong Murni', 21),
(58, 'Jambu Luwuk', 21),
(59, 'Banjar Sari', 21),
(60, 'Banjar Wangi', 21),
(61, 'Bitung Sari', 21),
(62, 'Teluk Pinang', 21),
(63, 'Banjar Waru', 21),
(64, 'Ciawi', 21),
(65, 'Pandasari', 21),
(66, 'Bendungan', 21),
(67, 'citeurep', 10),
(68, 'Gunung Sari', 10),
(69, 'Hambalang', 10),
(70, 'Karang Asem Barat', 10),
(71, 'Karang Asem Timur', 10),
(72, 'Leuwinutug', 10),
(73, 'Pasir Mukti', 10),
(74, 'Puspanegara', 10),
(75, 'Puspasari', 10),
(76, 'Sanja', 10),
(77, 'Sukahati', 10),
(78, 'Tajur', 10),
(79, 'Tangkil', 10),
(80, 'Tarikolot', 10),
(81, 'Citeurep', 10),
(82, 'Cadas Ngampar', 11),
(83, 'Cibanon', 11),
(84, 'Cijujung', 11),
(85, 'Cikeas', 11),
(86, 'Cilebut Barat', 11),
(87, 'Cilebut Timur', 11),
(88, 'Cimandala', 11),
(89, 'Gunung Geulis', 11),
(90, 'Nagrak', 11),
(91, 'Pasir Jambu', 11),
(92, 'Pasirlaja', 11),
(93, 'Sukaraja', 11),
(94, 'Sukatani', 11),
(95, 'Karanggan', 12),
(96, 'Gunung Putri', 12),
(97, 'Tlajung Udik', 12),
(98, 'Bojong Nangka', 12),
(99, 'Cicadas', 12),
(100, 'Wanaherang', 12),
(101, 'Cikeas', 12),
(102, 'Nagrag', 12),
(103, 'Ciangsana', 12),
(104, 'Bojong Kulur', 12),
(105, 'Babakan Madang', 13),
(106, 'Bojong Koneng', 13),
(107, 'Cijayanti', 13),
(108, 'Cipambuan', 13),
(109, 'Citaringgul', 13),
(110, 'Kadumangu', 13),
(111, 'Karang Tengah', 13),
(112, 'Sentul', 13),
(113, 'Sumur Batu', 13),
(114, 'Babakan', 14),
(115, 'Cibeuteung Muara', 14),
(116, 'Cibeuteung Udik', 14),
(117, 'Cibentang', 14),
(118, 'Cihoe', 14),
(119, 'Ciseeng', 14),
(120, 'Karihkil', 14),
(121, 'Kuripan', 14),
(122, 'Parigi Mekar', 14),
(123, 'Putat Nutug', 14),
(124, 'Atang Sanjaya', 15),
(125, 'Bojong', 15),
(126, 'Jampang', 15),
(127, 'Kemang', 15),
(128, 'Pabuaran', 15),
(129, 'Parakan Jaya', 15),
(130, 'Pondok Unik', 15),
(131, 'Semplak Barat', 15),
(132, 'Tegal', 15),
(133, 'Bantarjaya', 16),
(134, 'Bantarsari', 16),
(135, 'Candali', 16),
(136, 'Mekarsari', 16),
(137, 'Pasirgaok', 16),
(138, 'Rancabungur', 16),
(139, 'Cibadung', 17),
(140, 'Cibinong', 17),
(141, 'Cidokom', 17),
(142, 'Curug', 17),
(143, 'Gunung Sindur', 17),
(144, 'Jampang', 17),
(145, 'Pabuaran', 17),
(146, 'Padurenan', 17),
(147, 'Pengasinan', 17),
(148, 'Rawakalong', 17),
(149, 'Citayam', 18),
(150, 'Kalisuren', 18),
(151, 'Nanggerang', 18),
(152, 'Sasak Panjang', 18),
(153, 'Sukmajaya', 18),
(154, 'Tajur Halang', 18),
(155, 'Tonjong', 18),
(156, 'Bsngoang', 19),
(157, 'Barengkok', 19),
(158, 'Cikopomayak', 19),
(159, 'Curug', 19),
(160, 'Jasinga', 19),
(161, 'Jugala Jaya', 19),
(162, 'Kalongsawah', 19),
(163, 'Koleang', 19),
(164, 'Neglasari', 19),
(165, 'Pamegarsari', 19),
(166, 'Pangaur', 19),
(167, 'Pangradin', 19),
(168, 'Sipak', 19),
(169, 'Setu', 19),
(170, 'Tegal Wangi', 19),
(171, 'Wirajaya', 19),
(172, 'Cibadak', 8),
(173, 'Pabuaran', 8),
(174, 'Simajaya', 8),
(175, 'Sukadamai', 8),
(176, 'Sukaharja', 8),
(177, 'Sukamakmur', 8),
(178, 'Sukamulya', 8),
(179, 'Sukaresmi', 8),
(180, 'Sukawangi', 8),
(181, 'Wargajaya', 8),
(182, 'Antajaya', 6),
(183, 'Buanajaya', 6),
(184, 'Cibadak', 6),
(185, 'Pasir Tanjung', 6),
(186, 'Selawangi', 6),
(187, 'Simarasa', 6),
(188, 'Simasari', 6),
(189, 'Sukarasa', 6),
(190, 'Tanjungrasa', 6),
(191, 'Tanjungsari', 6),
(192, 'Babakan', 22),
(193, 'Batok', 22),
(194, 'Bojong', 22),
(195, 'Cilaku', 22),
(196, 'Ciomas', 22),
(197, 'Singabangsa', 22),
(198, 'Singabraja', 22),
(199, 'Tapos', 22),
(200, 'Tenjo', 22);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dinkes`
--

CREATE TABLE `tbl_dinkes` (
  `id` int(5) NOT NULL,
  `id_user` varchar(20) DEFAULT NULL,
  `nm_user` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_dinkes`
--

INSERT INTO `tbl_dinkes` (`id`, `id_user`, `nm_user`, `password`, `level`) VALUES
(1, 'ospri', 'ospri Harmi', '0192023a7bbd73250516f069df18b500', 'petugas'),
(2, 'slamet', 'slamet ', '21232f297a57a5a743894a0e4a801fc3', 'petugas'),
(7, 'sri', 'Sri Basuki', '827ccb0eea8a706c4c34a16891f84e7b', 'kabid'),
(8, 'yatna', 'Duriatna', '827ccb0eea8a706c4c34a16891f84e7b', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hospital`
--

CREATE TABLE `tbl_hospital` (
  `id_hospital` varchar(20) NOT NULL,
  `nm_hospital` varchar(50) DEFAULT NULL,
  `address` text,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_hospital`
--

INSERT INTO `tbl_hospital` (`id_hospital`, `nm_hospital`, `address`, `password`, `status`) VALUES
('RS001', 'RSUD Cibinong', 'jl. cikaret', '1f32aa4c9a1d2ea010adcf2348166a04', '2'),
('RS002', 'RSUD Leuwiliang', 'leuwiliang', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
('RS003', 'RS PMI', 'jl Raya Bogor', '827ccb0eea8a706c4c34a16891f84e7b', NULL),
('RS004', 'RSUD Bogor', 'Jl Raya Bogor', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
('RS005', 'RS MEDIKA', 'Bogor', '827ccb0eea8a706c4c34a16891f84e7b', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jaminan`
--

CREATE TABLE `tbl_jaminan` (
  `no_jaminan` varchar(25) NOT NULL,
  `tgl_permohonan` date NOT NULL,
  `nm_peserta` varchar(50) NOT NULL,
  `nik_peserta` varchar(50) NOT NULL,
  `jk` enum('1','2') NOT NULL,
  `tmp_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `status_kawin` enum('0','1','2','3') NOT NULL,
  `alamat` text NOT NULL,
  `rt` int(5) DEFAULT NULL,
  `rw` int(5) DEFAULT NULL,
  `id_kecamatan` int(5) DEFAULT NULL,
  `id_desa` int(5) DEFAULT NULL,
  `diagnosis` text NOT NULL,
  `skkm_dinsos` varchar(100) NOT NULL,
  `id_hospital` varchar(5) NOT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_jaminan`
--

INSERT INTO `tbl_jaminan` (`no_jaminan`, `tgl_permohonan`, `nm_peserta`, `nik_peserta`, `jk`, `tmp_lahir`, `tgl_lahir`, `status_kawin`, `alamat`, `rt`, `rw`, `id_kecamatan`, `id_desa`, `diagnosis`, `skkm_dinsos`, `id_hospital`, `status`) VALUES
('P0001/V/Promkes-SDK/2016', '2016-06-05', 'Agus Setiawan', '130442070005', '', 'bogor', '1994-08-11', '1', 'jatijajar no.67', 3, 18, 1, 1, 'demam tinggi', 'http://localhost/jamkesda/file_upload/2ea1911c1556fc5d1d924bea744ba4dd.jpg', 'RS001', 'done'),
('P0002/V/Promkes-SDK/2016', '2016-05-13', 'Sandy', '3008589938958737', '1', 'bogor', '2000-06-06', '1', 'Bojong', 3, 5, 1, 1, 'Radang ', 'http://localhost/jamkesda/file_upload/b18f844e5fd8ae80fc70eedc7f8532e7.jpg', 'RS001', 'done'),
('P0003/V/Promkes-SDK/2016', '2016-05-19', 'Ramones', '909488478848988', '1', 'Bogor', '1997-02-12', '1', 'bojong', 4, 5, 1, 1, 'panas tinggi', 'http://localhost/jamkesda/file_upload/bee321d4a88a92d4ccb11919862aa718.jpg', 'RS001', 'done'),
('P0004/VI/Promkes-SDK/2016', '2016-06-06', 'Reni', '4349283482903849890', '', 'Bogor', '1995-02-12', '3', 'jatijajar', 3, 18, 1, 1, 'kelenjar', 'http://localhost/jamkesda/file_upload/ad9eaeb760b86742ee3f70c5ab7fec78.jpg', 'RS002', 'done'),
('P0005/V/Promkes-SDK/2016', '2016-05-21', 'Rony', '348297725874598', '1', 'Bogor', '1978-08-11', '2', 'bojong', 4, 5, 1, 1, 'panas tinggi', 'http://localhost/jamkesda/file_upload/a66f29c35ab5ac793ca38d954cfd14fe.jpg', 'RS001', 'done'),
('P0006/V/Promkes-SDK/2016', '2016-05-22', 'Rei', '348297725874598431234', '1', 'Bogor', '1978-08-11', '3', 'bojong', 4, 5, 1, 1, 'panas tinggi', 'http://localhost/jamkesda/file_upload/bd6b4d8ba05b3e8f249f43b960b4bfe9.jpg', 'RS001', 'done'),
('P0007/V/Promkes-SDK/2016', '2016-05-23', 'Sony', '32019989883878', '1', 'Ciampea', '1960-08-11', '2', 'ciampea', 5, 6, 1, 1, 'Demam Tinggi', 'http://localhost/jamkesda/file_upload/b1ee2aee7633ac87ae416bb7c10e0cb5.jpg', 'RS001', 'done'),
('P0008/V/Promkes-SDK/2016', '2016-05-23', 'Nike', '34829772587421312', '2', 'Bogor', '1994-08-11', '1', 'CIlangkap', 4, 8, 1, 1, 'Kelenjar ', 'http://localhost/jamkesda/file_upload/847d15d1e37cc434de7921b407685ae9.jpg', 'RS002', 'done'),
('P0009/V/Promkes-SDK/2016', '2016-05-23', 'Rio', '3201998988387821', '1', 'Bogor', '1990-07-10', '1', 'Cilangkap', 1, 1, 1, 1, 'Panas Tinggi', 'http://localhost/jamkesda/file_upload/428638a7da470fe0f11cbce821d662fc.jpg', 'RS001', 'done'),
('P0010/V/Promkes-SDK/2016', '2016-05-23', 'Fai', '32019989883878231', '2', 'Bogor', '1996-07-10', '1', 'dfasdfas', 1, 8, 1, 1, '......', 'http://localhost/jamkesda/file_upload/016e2615cc9583a3fa16a4c0ccc218c8.jpg', 'RS001', 'done'),
('P0011/VI/Promkes-SDK/2016', '2016-06-01', 'Andry', '84958392408304', '1', 'Bogor', '1996-02-06', '1', 'bogor', 1, 8, 1, 1, 'csafdsa', 'http://localhost/jamkesda/file_upload/f0f4ae574d0f166812c2430053f86ecb.jpg', 'RS001', 'done'),
('P0012/VI/Promkes-SDK/2016', '2016-06-06', 'Agus Setiawan', '130442070005', '', 'Bogor', '1994-08-11', '1', 'jl. Pintu Air Sidamukti no.67', 1, 1, 1, 1, 'kelenjar', 'http://localhost/jamkesda/file_upload/2bb8a7a621bce14c533658bd1ae48ab6.jpg', 'RS001', 'done'),
('P0013/VI/Promkes-SDK/2016', '2016-06-06', 'Rina Pindari', '3201394707840003', '2', 'Bogor', '1984-07-07', '2', 'Kp. Lio Jambu', 3, 1, 2, 13, 'panas tinggi', 'http://localhost/jamkesda/file_upload/f501d942a615d7658cb357b543f348df.jpg', 'RS002', 'done'),
('P0014/VI/Promkes-SDK/2016', '2016-06-10', 'dody', '32019989883878231', '2', 'Bogor', '1984-07-07', '2', 'Bogor', 1, 8, 6, 182, 'Demam Tinggi', 'http://localhost/jamkesda/file_upload/e9d324e5700ca1b373042910f84f54c8.jpg', 'RS002', 'done'),
('P0015/VI/Promkes-SDK/2016', '2016-06-29', 'Rina Pindari', '130442070005', '2', 'Bogor', '1984-07-07', '2', 'bogor', 1, 8, 9, 44, 'kelenjar', 'http://localhost/jamkesda/file_upload/601dc1012e93df6596507c684d114164.jpg', 'RS004', 'done');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kecamatan`
--

CREATE TABLE `tbl_kecamatan` (
  `id_kecamatan` int(5) NOT NULL,
  `kecamatan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kecamatan`
--

INSERT INTO `tbl_kecamatan` (`id_kecamatan`, `kecamatan`) VALUES
(1, 'Bojong Gede'),
(2, 'Leuwisadeng'),
(4, 'Jonggol'),
(5, 'Cariu'),
(6, 'Tanjung Sari'),
(7, 'Cileungsi'),
(8, 'Sukamakmur'),
(9, 'Cibinong'),
(10, 'Citeurep'),
(11, 'Sukaraja'),
(12, 'Gunung Putri'),
(13, 'Babakan Madang'),
(14, 'Ciseeng'),
(15, 'Kemang'),
(16, 'Rancabungur'),
(17, 'Gunung Sindur'),
(18, 'Tajur Halang'),
(19, 'Jasinga'),
(20, ''),
(21, 'Ciawi'),
(22, 'Tenjo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_biaya`
--
ALTER TABLE `tbl_biaya`
  ADD PRIMARY KEY (`id_biaya`),
  ADD KEY `id_hospital` (`id_hospital`),
  ADD KEY `FK_tbl_biaya` (`no_jaminan`);

--
-- Indexes for table `tbl_desa`
--
ALTER TABLE `tbl_desa`
  ADD PRIMARY KEY (`id_desa`),
  ADD KEY `id_kecamatan` (`id_kecamatan`);

--
-- Indexes for table `tbl_dinkes`
--
ALTER TABLE `tbl_dinkes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_hospital`
--
ALTER TABLE `tbl_hospital`
  ADD PRIMARY KEY (`id_hospital`);

--
-- Indexes for table `tbl_jaminan`
--
ALTER TABLE `tbl_jaminan`
  ADD PRIMARY KEY (`no_jaminan`),
  ADD KEY `FK_tbl_jaminan` (`id_kecamatan`);

--
-- Indexes for table `tbl_kecamatan`
--
ALTER TABLE `tbl_kecamatan`
  ADD PRIMARY KEY (`id_kecamatan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_biaya`
--
ALTER TABLE `tbl_biaya`
  MODIFY `id_biaya` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_desa`
--
ALTER TABLE `tbl_desa`
  MODIFY `id_desa` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;
--
-- AUTO_INCREMENT for table `tbl_dinkes`
--
ALTER TABLE `tbl_dinkes`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_kecamatan`
--
ALTER TABLE `tbl_kecamatan`
  MODIFY `id_kecamatan` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_biaya`
--
ALTER TABLE `tbl_biaya`
  ADD CONSTRAINT `FK_tbl_biaya` FOREIGN KEY (`no_jaminan`) REFERENCES `tbl_jaminan` (`no_jaminan`),
  ADD CONSTRAINT `tbl_biaya_ibfk_2` FOREIGN KEY (`id_hospital`) REFERENCES `tbl_hospital` (`id_hospital`);

--
-- Constraints for table `tbl_jaminan`
--
ALTER TABLE `tbl_jaminan`
  ADD CONSTRAINT `FK_tbl_jaminan` FOREIGN KEY (`id_kecamatan`) REFERENCES `tbl_desa` (`id_kecamatan`),
  ADD CONSTRAINT `tbl_jaminan_ibfk_1` FOREIGN KEY (`id_kecamatan`) REFERENCES `tbl_kecamatan` (`id_kecamatan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
