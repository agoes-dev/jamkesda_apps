<div><br>
	<?php echo anchor('rumahsakit/add','Tambah Rumah Sakit','class="btn btn-success"');?>
</div>
<br>
<div class="table-responsive col-md-12">
	<table id="hospital" class="table table-bordered table-hover">
		<thead>
			<th><center>No</center></th>
			<th><center>RS Code</center></th>
			<th><center>Username</center></th>
			<th><center>Address</center></th>
			<th><center>Status</center></th>
			<th><center>Action</center></th>
		</thead>
	
	<?php 
	$no = 0;
	?>

		<tbody>
			<?php foreach ($hospital as $row):?>
			<tr align="center">
				<td><?php echo ++$no;?></td>
				<td><?php echo $row->id_hospital;?></td>
				<td><?php echo $row->nm_hospital;?></td>
				<td><?php echo $row->address;?></td>
				<td>
				<?php
					if($row->status == 1){
						echo 'Aktif';
					}else if($row->status == 2){
						echo 'Tidak Aktif';
					}else{
						echo 'Not Configure';
					} 
				?>
				</td>
				<td><?php echo anchor('rumahsakit/edit/'.$row->id_hospital,' ','class="span glyphicon glyphicon-pencil"');?></td>
			</tr>
	<?php endforeach;?>		
		</tbody>
</table>
<?php echo $error;?>
</div>