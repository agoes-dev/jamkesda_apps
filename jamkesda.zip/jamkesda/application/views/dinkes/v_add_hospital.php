<div class="col-md-4">
<h4><strong><center>TAMBAH RUMAH SAKIT</center></strong></h4>
<br>
	<?php echo form_open_multipart('rumahsakit/save');?>
	
	<label>Kode Rumah Sakit</label>
	<?php echo form_input('id_hospital',$kode_rs,'class="form-control" readonly');?>
	<br>
	<label>Nama Rumah Sakit</label>
	<?php echo form_input('nm_hospital','','class="form-control"');?>
	<br>
	<label>Address</label>
	<textarea name="address" rows="3" class="form-control"></textarea>
	<br>
	<label>Password</label>
	<?php echo form_password('password','','class="form-control"');?>
	<br>
	<?php echo form_submit('submit','Save','class="btn btn-success"');?>
	<?php echo form_reset('reset','Reset','class="btn btn-warning"');?>
	<?php echo form_close();?>
	<br>
</div>
<div class="col-md-4">
	<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>

    <?php echo $error;?>
</div>
