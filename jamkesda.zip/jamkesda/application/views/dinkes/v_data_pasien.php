	<h4>No. Jaminan : <u><?php echo $title;?></u></h4>
	<div class="col-md-4">
		<label>Nama Pasien/Pemohon</label>
		<?php echo form_input('',$jaminan->nm_pasien,'class="form-control" readonly');?>
		<br>
		<!--<label>Tgl Permohonan</label>
		<?php echo form_input('',date('d M Y', strtotime($jaminan->tgl_permohonan)),'class="form-control" readonly');?>
		<br>
		<label>Rumah Sakit</label>
		<?php echo form_input('',$jaminan->nm_hospital,'class="form-control" readonly');?>
		<br>-->
		<label>NIK</label>
		<?php echo form_input('',$jaminan->nik_pasien,'class="form-control" readonly');?>
		<br>
		<label>Tempat Lahir</label>
		<?php echo form_input('',$jaminan->tmp_lahir,'class="form-control" readonly');?>
		<br>
		<label>Tanggal Lahir</label>
		<?php echo form_input('',$jaminan->tgl_lahir,'class="form-control" readonly');?>
		<br>
		<!--<label>Status</label>
		<?php 
			if($jaminan->status == 0){
				echo form_input('','Tidak Menikah','class="form-control" readonly');
			}else if($jaminan->status == 1){
				echo form_input('','Belum Menikah','class="form-control" readonly');
			}else if ($jaminan->status == 2) {
				echo form_input('','Menikah','class="form-control" readonly');
			}else{
				echo form_input('','Cerai','class="form-control" readonly');
			}
		?>-->
		<label>Alamat</label>
		<textarea name="" class="form-control" readonly><?php echo $jaminan->alamat_pasien;?></textarea>
		<br>
		<div class="col-md-5">
			<label>RT</label>
			<?php echo form_input('',$jaminan->rt,'class="form-control" readonly');?>
			
		</div>
		<div class="col-md-5">
			<label>RW</label>
			<?php echo form_input('',$jaminan->rw,'class="form-control" readonly');?>
		<br>

		</div>
		</div>
		<div class="col-md-4">
		<label>Kecamatan</label>
		<?php echo form_input('',$jaminan->kecamatan,'class="form-control" readonly');?>
		<br>
		<label>Desa</label>
		<?php echo form_input('',$jaminan->desa,'class="form-control" readonly');?>
		<br>
		<label>Diagnosis</label>
		<textarea name="" class="form-control" readonly><?php echo $jaminan->diagnosis;?></textarea>
		<br>
		<label>SKKM DINSOS</label>
		<?php echo anchor($jaminan->skkm_dinsos,'lihat');?>
		<br>
		<label>SKKM KEPALA DESA</label>
		<?php echo anchor($jaminan->skkm_kepala_desa,'lihat');?>
		</div>
