<h4>Edit Data User <?php echo $user->nm_user;?></h4>

<div class="col-md-4">
<?php echo form_open('user/update');?>
<?php echo form_hidden('id',$user->id);?>
	<label>User ID</label>
	<?php echo form_input('userid',$user->id_user,'class="form-control"');?>
	<br>
	<label>Username</label>
	<?php echo form_input('username',$user->nm_user,'class="form-control"');?>
	<br>
	<label>Password</label>
	<?php echo form_password('password',$user->password,'class="form-control"');?>
	<br>
	<label>Level</label>
	<?php echo form_input('level',ucfirst($user->level),'class="form-control" readonly');?>
	<br>
	<?php echo form_submit('submit','Update','class="btn btn-success"');?>
	<?php echo anchor('user','Cancel','class="btn btn-warning"');?>
	<?php echo form_close();?>
</div>
<div class="col-md-4">
	<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
    <?php echo $error;?>	
</div>