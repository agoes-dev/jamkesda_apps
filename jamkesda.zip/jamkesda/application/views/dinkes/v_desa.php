<label>Desa/Kelurahan</label>
<?php echo form_dropdown('desa',$option_desa,'','class="form-control"');?>