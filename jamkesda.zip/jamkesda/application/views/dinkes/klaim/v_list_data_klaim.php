<div class="table-responsive">
<?php echo anchor('klaim/claim_in','Klaim Masuk','class="btn btn-success"');?>
<br><br>
	<table id="klaim" class="table table-bordered table-hovered">
		<thead>
			<tr>
				<td>No</td>
				<td>Kode RS</td>
				<td>Nama RS</td>
				<td>No Jaminan</td>
				<td>Tanggal Permohonan</td>
				<td>Tanggal Selesai Dirawat</td>
				<td>Biaya Perawatan</td>
				<td>Resume Medis</td>
				<td>Action</td>
			</tr>

			<?php 
			$no=0;
			?>
			
				<tbody>
				<?php foreach ($klaim as $row ):?>
					<tr>
						<td><?php echo ++$no;?></td>
						<td><?php echo $row->id_hospital;?></td>
						<td><?php echo $row->nm_hospital;?></td>
						<td><?php echo $row->no_jaminan;?></td>
						<td><?php echo date('d M Y',strtotime($row->tgl_permohonan));?></td>
						<td><?php echo date('d M Y',strtotime($row->tgl_selesai));?></td>
						<td><?php echo "Rp.".number_format($row->total_biaya,2);?></td>
						<td align="center"><?php echo anchor($row->kwitansi,' ','class="span glyphicon glyphicon-eye-open"');?></td>
						<td align="center"><?php echo anchor('klaim/edit/'.$row->id_biaya,' ','class="span glyphicon glyphicon-pencil"');?></td>
					</tr>
				<?php endforeach;?>
				</tbody>
		</thead>
	</table>
</div>