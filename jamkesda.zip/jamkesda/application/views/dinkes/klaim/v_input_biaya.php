<h4>Resume Medis</h4>
<div class="col-md-6">
	<img src="<?php echo $klaim->kwitansi;?>" width="500">
</div>
<div class="col-md-4">
<?php echo form_open('klaim/insert');?>
<?php echo form_hidden('id_biaya',$klaim->id_biaya);?>
	<label>No Jaminan</label>
	<?php echo form_input('no_jaminan',$klaim->no_jaminan,'class="form-control" readonly');?>
	<br>
	<label>Masukkan Total Biaya Perawatan</label>
	<?php echo form_input('total_biaya','','class="form-control" placeholder="Rp."');?>
	<br>
	<?php echo form_submit('submit','Submit','class="btn btn-success"');?>
	<?php echo form_reset('reset','Reset','class="btn btn-warning"');?>
<?php echo form_close();?>
<br>
<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
    <?php echo $error;?>
</div>

