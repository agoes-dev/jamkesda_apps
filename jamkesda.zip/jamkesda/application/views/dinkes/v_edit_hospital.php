<div class="col-md-4">
<h4><strong><center><?php echo strtoupper($title);?></center></strong></h4>
<br>
	<?php echo form_open_multipart('rumahsakit/update');?>
	
	<label>Kode Rumah Sakit</label>
	<?php echo form_input('id_hospital',$rs->id_hospital,'class="form-control" readonly');?>
	<br>
	<label>Nama Rumah Sakit</label>
	<?php echo form_input('nm_hospital',$rs->nm_hospital,'class="form-control"');?>
	<br>
	<label>Address</label>
	<textarea name="address" rows="4" class="form-control"><?php echo $rs->address;?></textarea>
	<br>
	<label>Password</label>
	<?php echo form_password('password',$rs->password,'class="form-control"');?>
	<br>
	<label>Status</label>
	<br>
	<?php
			if($rs->status  == '1'){
				echo '<input type="radio" name="status" value="1" checked>Aktif</input>&nbsp <input type="radio" name="status" value="2">Tidak Aktif</input>';		
			}else if($rs->status == '2'){
				echo '<input type="radio" name="status" value="1">Aktif</input>&nbsp <input type="radio" name="status" value="2" checked>Tidak Aktif</input>';		
			}else{
				echo '<input type="radio" name="status" value="1">Aktif</input>&nbsp <input type="radio" name="status" value="2">Tidak Aktif</input>';
			}
		?>
		<br><br>
	<?php echo form_submit('submit','Update','class="btn btn-success"');?>
	<?php echo anchor('rumahsakit','Cancel','class="btn btn-warning"');?>

	<?php echo form_close();?>
	<br>
</div>
<div class="col-md-4">
	<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>

    <?php echo $error;?>
</div>
