<h4>SILAHKAN MASUKAN DATA PENERIMA JAMINAN</h4>

	<?php echo form_open_multipart('jaminan/update');?>
	<?php echo form_hidden('id',$jaminan->no_jaminan);?>
	<div class="col-md-4">
		<label>No Jaminan</label>
		<?php echo form_input('no_jaminan',$jaminan->no_jaminan,'class="form-control" readonly');?>

<?php echo form_hidden('id',$jaminan->no_jaminan);?>
	<br>
		<label>Rumah Sakit :</label>
		<?php echo form_hidden('hospital',$jaminan->id_hospital);?>
		<u><i><?php echo $jaminan->nm_hospital;?></i></u>
		<?php echo form_dropdown('hospital_baru',$option_hospital,'','class="form-control"');?>
	<br>
		<?php echo form_label('Nama Lengkap Pasien');?>
		<?php echo form_input('nama_pasien',$jaminan->nm_peserta,'class="form-control"');?>
	<br>
		<?php echo form_label('NIK Pasien');?>
		<?php echo form_input('nik_pasien',$jaminan->nik_peserta,'class="form-control"');?>
	<br>
		<?php echo form_label('Jenis Kelamin');?><br>
		<?php
			if($jaminan->jk  == '1'){
				echo '<input type="radio" name="jk" value="laki-laki" checked>Laki-laki</input>&nbsp <input type="radio" name="jk" value="perempuan">Perempuan</input>';		
			}else{
				echo '<input type="radio" name="jk" value="laki-laki">Laki-laki</input>&nbsp <input type="radio" name="jk" value="perempuan" checked>Perempuan</input>';		
			}
		?>
		
	<br><br>
		<?php echo form_label('Tempat Lahir');?>
		<?php echo form_input('tempat_lahir',$jaminan->tmp_lahir,'class="form-control"');?>
	<br>
		<?php echo form_label('Tanggal Lahir');?>
		<div class="form-group">
       <div class='input-group date' id='datepicker'>
        <input type='text' name="tanggal_lahir" value="<?php echo date(" d-m-Y ", strtotime($jaminan->tgl_lahir));?>" class="form-control" />
        <span class="input-group-addon">
         <span class="glyphicon glyphicon-calendar"></span>
        </span>
       </div>
      </div>
	</div>
	<div class="col-md-4">
	    <label>Status Kawin :</label>
	    <u><i>
	    <?php echo form_hidden('status',$jaminan->status_kawin);?>
	    
	    	<?php
	    		if($jaminan->status_kawin == 1){
	    			echo "Belum Menikah";			
	    		}elseif ($jaminan->status_kawin == 2) {
	    			echo "Menikah";
	    		}elseif ($jaminan->status_kawin == 3) {
	    			echo "Cerai";
	    		}else{
	    			echo "Tidak Menikah";
	    		}
	    	?>
	    </i></u>
		<select name="status_baru" class="form-control">
			<option value="">Choose Status</option>
			<option value="0">Tidak Menikah</option>
			<option value="1">Belum Menikah</option>
			<option value="2">Menikah</option>
			<option value="3">Cerai</option>
		</select>
		<br>
		
		<?php echo form_label('Alamat');?>
		<textarea name="alamat_pasien" rows="1" class="form-control"><?php echo $jaminan->alamat;?></textarea>
	<br>
	<div class="col-md-5">
		<label>RT</label>
		<?php echo form_input('rt',$jaminan->rt,'class="form-control"');?>
	</div>
	<div class="col-md-5">
		<label>RW</label>
		<?php echo form_input('rw',$jaminan->rw,'class="form-control"');?>		
	</div>

	<br/><br/><br/><br/>
	<div id="kecamatan">
		<label>Kecamatan :</label>
		<u><i><?php echo $jaminan->kecamatan;?></i></u>
		<?php echo form_hidden('kecamatan',$jaminan->id_kecamatan);?>
		<?php echo form_dropdown('kecamatan_baru',$option_kecamatan,'','class="form-control" id=kecamatan_id','id=kecamatan_id');?>
	</div>
	<br>
	<div id="desa">
		<label>Desa/Kelurahan :</label>
		<u><i><?php echo $jaminan->desa;?></i></u>
		<?php echo form_hidden('desa',$jaminan->id_desa);?>
		<?php
        echo form_dropdown('desa_id',array('Pilih Kota / Kabupaten'=>'Pilih Kecamatan Dahulu'),'','class="form-control"','disabled');
    ?>
	</div>
	<br>
		<label>Diagnosis</label>
		<textarea name="diagnosis" rows="3" class="form-control"><?php echo $jaminan->diagnosis;?></textarea>
		<br/>			
	</div>
	<div class="col-md-4">
	<?php echo form_label('Upload SKKM DINSOS');?>

		<input type="file" name="gambar" size="20" />
		<?php echo form_hidden('skkm',$jaminan->skkm_dinsos);?>
		<img src="<?php echo $jaminan->skkm_dinsos;?>" width="100">

	<br><br>
	<?php echo form_submit('submit','Update','class="btn btn-success"');?>
		<?php echo anchor('jaminan','Back','class="btn btn-warning"');?>
		<?php echo $error;?>
		<br><br>
		<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
	</div>
	<?php echo form_close();?>

	<!-- 
	Untuk Dropdown Kecamatan dan desa
	-->
	<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
	<script type="text/javascript">
		$("#kecamatan_id").change(function(){
			var selectValues = $('#kecamatan_id').val();
			if(selectValues == 0){
				var msg = "<label>Desa/Kelurahan</label><br><select name='' class='form-control'><option value=''>Pilih Kecamatan Dahulu</option></select>";
				$('#desa').html(msg);
			}else{
				var kecamatan_id = {kecamatan_id:$("#kecamatan_id").val()};
				$.ajax({
				type: "POST",
				url : "<?php echo site_url('dinkes/select_desa');?>",
				data: kecamatan_id,
				success: function(msg){
					$('#desa').html(msg);
					//alert(msg);
				}
			});	
			}
			
		});
	</script>