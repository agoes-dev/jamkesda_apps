
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery-1.4.3.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url();?>assets/js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/morris-data.js"></script>
    
</body>
<script src="<?php echo base_url();?>assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-datetimepicker.min.js"></script>

<script src="<?php echo base_url();?>assets/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/js/dataTables.bootstrap.js"></script>
<!--<script src="<?php echo base_url();?>assets/js/jquery-1.11.0.js"></script>-->
<script type="text/javascript">
  $(function(){
    $("#hospital").DataTable({
      "searching": false
    });
  });

  $(document).ready(function(){
    $("#jaminan").dataTable();
  });
  //untuk table klaim
  $(document).ready(function(){
    $("#klaim").dataTable({
      "searching": false
    });
  });
   $(document).ready(function(){
    $("#klaim_masuk").dataTable({
      "searching": false,
      "ordering": false
    });
  });
   $(document).ready(function(){
    $("#user").dataTable({
      "searching": false
    });
  });
</script>


<script type="text/javascript">
 $(function () {
  $('#datetimepicker').datetimepicker({
   format: 'DD MMMM YYYY HH:mm',
  });
  
  $('#datepicker').datetimepicker({
   format: 'DD-MM-YYYY',
  });
  
  $('#timepicker').datetimepicker({
   format: 'HH:mm'
  }); 
 });

        </script>
<script type="text/javascript">
    $(document).ready(function(){
      setInterval(function(){
        $('#klaim_rs').load('<?php echo site_url();?>dinkes/claim_in')
      },1000);
    });
</script>
</html>
