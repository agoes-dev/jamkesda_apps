<h4>Tambah User</h4>
<div class="col-md-4">
<?php echo form_open('user/save');?>
	<label>User ID</label>
	<?php echo form_input('userid','','class="form-control"');?>
	<br>
	<label>Username</label>
	<?php echo form_input('username','','class="form-control"');?>
	<br>
	<label>Password</label>
	<?php echo form_password('password','','class="form-control"');?>
	<br>
	<label>Level</label><br>
	<input type="radio" name="level" value="petugas">Petugas</input>&nbsp;
	<input type="radio" name="level" value="kabid">Kabid</input>
	<br><br>
	<?php echo form_submit('submit','Submit','class="btn btn-success"');?>
	<?php echo form_reset('reset','Reset','class="btn btn-warning"');?>
<?php echo form_close();?>

</div>
<div class="col-md-4">
	<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
    <?php echo $error;?>	
</div>
