<?php echo anchor('user/add','Tambah User','class="btn btn-success"');?><br><br>
<div class="table-responsive">
	<table id="user" class="table table-bordered">
		<thead>
		<tr align="center">
			<td>No</td>
			<td>User ID</td>
			<td>Username</td>
			<td>Level</td>
			<td>Action</td>
		</tr>
		</thead>
		<?php
		$no=0;
		?>
		<tbody>
		<?php foreach ($user as $row):?>
			<tr align="center">
				<td><?php echo ++$no;?></td>
				<td><?php echo $row->id_user;?></td>
				<td><?php echo ucfirst($row->nm_user);?></td>
				<td><?php echo ucfirst($row->level);?></td>
				<td><?php echo anchor('user/edit/'.$row->id,' ','class="span glyphicon glyphicon-pencil"')." | ".anchor('user/delete/'.$row->id,' ','class="span glyphicon glyphicon-remove"',array('onclick'=>"return confirm('Are You Sure Want to Delete?')"));?></td>
			</tr>
		<?php endforeach;?>
		</tbody>
	</table>
</div>