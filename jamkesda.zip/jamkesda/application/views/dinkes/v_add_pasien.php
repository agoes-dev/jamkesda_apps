<h4>SILAHKAN MASUKAN DATA PENERIMA JAMINAN</h4> 

	<?php echo form_open_multipart('dinkes/save_pasien');?>
	<div class="col-md-4">
		<label>No Jaminan</label>
		<?php echo form_input('no_jaminan',$no_jaminan,'class="form-control" readonly');?>
	<br>
		<label>Rumah Sakit</label>

		<?php echo form_dropdown('hospital',$option_hospital,'','class="form-control"');?>
	<br>
		<?php echo form_label('Nama Lengkap');?>
		<?php echo form_input('nama_pasien','','class="form-control"');?>
	<br>
		<?php echo form_label('NO KTP');?>
		<?php echo form_input('nik_pasien','','class="form-control"');?>
	<br>
		<?php echo form_label('Jenis Kelamin');?><br>
		<input type="radio" name="jk" value="1">Laki-laki</input>&nbsp;
		<input type="radio" name="jk" value="2">Perempuan</input>
	<br><br>
		<?php echo form_label('Tempat Lahir');?>
		<?php echo form_input('tempat_lahir','','class="form-control"');?>
	<br>
		<?php echo form_label('Tanggal Lahir');?>
		<div class="form-group">
       <div class='input-group date' id='datepicker'>
        <input type='text' name="tanggal_lahir" class="form-control" />
        <span class="input-group-addon">
         <span class="glyphicon glyphicon-calendar"></span>
        </span>
       </div>
      </div>
	</div>

	<div class="col-md-4">
	    <?php echo form_label('Status Kawin');?><br>
		<select name="status" class="form-control">
			<option value="">Pilih Status</option>
			<option value="0">Tidak Menikah</option>
			<option value="1">Belum Menikah</option>
			<option value="2">Menikah</option>
			<option value="3">Cerai</option>
		</select>
		<br>
		
		<?php echo form_label('Alamat');?>
		<textarea name="alamat_pasien" rows="1" class="form-control"></textarea>
	<br>
	<div class="col-md-5">
		<label>RT</label>
		<?php echo form_input('rt','','class="form-control"');?>
	</div>
	<div class="col-md-5">
		<label>RW</label>
		<?php echo form_input('rw','','class="form-control"');?>		
	</div>

	<br/><br/><br/><br/>
	<div id="kecamatan">
		<label>Kecamatan</label>
		<?php echo form_dropdown('kecamatan',$option_kecamatan,'','class="form-control" id=kecamatan_id','id=kecamatan_id');?>
	</div>
	<br>
	<div id="desa">
		<label>Desa/Kelurahan</label>
		<?php
        echo form_dropdown('desa_id',array('Pilih Kota / Kabupaten'=>'Pilih Kecamatan Dahulu'),'','class="form-control"','disabled');
    ?>
	</div>
	<br>
		<label>Diagnosis</label>
		<textarea name="diagnosis" rows="3" class="form-control"></textarea>
		<br/>	
		<!--<?php echo form_label('Nama Pemohon :');?>
		<?php echo form_input('nama_pemohon','','class="form-control"');?>
	<br>
		<?php echo form_label('No. Telp Pemohon :');?>
		<?php echo form_input('phone','','class="form-control"');?>
	<br>-->dasdas
		
		
	</div>
	<div class="col-md-4">
	<?php echo form_label('Upload SKKM DINSOS');?>
		<input type="file" name="gambar1" size="20" />
	<!--<br>
		<?php echo form_label('Upload SKKM Kepala Desa');?>
		<input type="file" name="gambar2" size="20" />-->
	<br>
	<?php echo form_submit('submit','Submit','class="btn btn-success"');?>
		<?php echo form_reset('reset','Reset','class="btn btn-warning"');?>
		<?php echo $error;?>
		<br><br>
		<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
	</div>
	<?php echo form_close();?>

	<!-- 
	Untuk Dropdown Kecamatan dan desa
	-->
	<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
	<script type="text/javascript">
		$("#kecamatan_id").change(function(){
			var selectValues = $('#kecamatan_id').val();
			if(selectValues == 0){
				var msg = "<label>Desa/Kelurahan</label><br><select name='' class='form-control'><option value=''>Pilih Kecamatan Dahulu</option></select>";
				$('#desa').html(msg);
			}else{
				var kecamatan_id = {kecamatan_id:$("#kecamatan_id").val()};
				$.ajax({
				type: "POST",
				url : "<?php echo site_url('dinkes/select_desa');?>",
				data: kecamatan_id,
				success: function(msg){
					$('#desa').html(msg);
					//alert(msg);
				}
			});	
			}
			
		});
	</script>