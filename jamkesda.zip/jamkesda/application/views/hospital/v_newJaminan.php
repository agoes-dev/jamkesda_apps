<?php
	echo $jaminan;
?>