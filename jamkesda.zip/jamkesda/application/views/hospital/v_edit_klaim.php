<div class="col-md-4">
	<h3><?php echo $title;?></h3>
	<br>
	<?php echo form_open_multipart('hospital/update');?>
	<label>No Jaminan</label>
	<?php echo form_hidden('id_biaya',$peserta->id_biaya);?>
	<br>
	<?php echo form_input('no_jaminan',$peserta->no_jaminan,'class="form-control" readonly');?>
	<br>
	<label>Upload Resume Medis</label>
	<br>
	<?php echo form_upload('userfile');?>
	<br>
	<img src="<?php echo $peserta->kwitansi;?>" width="100">
	<br><br>
	<?php echo form_submit('submit','Update','class="btn btn-success"');?>
	<?php echo anchor('hospital/listPerawatan/'.$this->session->userdata('id_user'),'Cancel','class="btn btn-warning"');?>
	<?php echo form_close();?>
	<br>
	<?php echo $error;?>
		<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
</div>