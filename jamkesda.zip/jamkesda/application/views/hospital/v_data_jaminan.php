<?php
	if($peserta == 0){
		echo "<h4>Tidak Ada Jaminan Masuk</h4>";
	}else{
		echo "<h4>Jaminan Masuk</h4>";
	}
?>
<div class="table-responsive">
	<table id="newjaminan" class="table table-hover table-bordered">
		<thead>
			<tr>
				<td><center>No</center></td>
				<td><center>No Jaminan</center></td>
				<td><center>Nama Peserta</center></td>
				<td><center>No NIK</center></td>
				<td><center>Jenis Kelamin</center></td>
				<td><center>Status Kawin</center></td>
				<td><center>Diagnosis</center></td>
				<td><center>SKKM</center></td>
				<td><center>Action</center></td>
			</tr>
			</thead>
			
			<?php 
				$no=0;
			?>
			<tbody align="center">
			<?php foreach ($jaminan as $row):?>

				<tr>
					<td><?php echo ++$no;?></td>
					<td><?php echo $row->no_jaminan;?></td>
					<td><?php echo $row->nm_peserta;?></td>
					<td><?php echo $row->nik_peserta;?></td>
					<?php 
						if($row->jk == 1){
							echo "<td>Laki-laki</td>";
						}else{
							echo "<td>Perempuan</td>";
						}
					?>
					<?php
						if($row->status_kawin == 1){
							echo "<td>Belum Menikah</td>";
						}elseif ($row->status_kawin == 2) {
							echo "<td>Menikah</td>";
						}elseif ($row->status_kawin == 3) {
							echo "<td>Cerai</td>";
						}else{
							echo "<td>Tidak Menikah</td>";
						}
					?>
					<td><?php echo $row->diagnosis;?></td>
					<td><?php echo anchor($row->skkm_dinsos,' ','class="span glyphicon glyphicon-eye-open"');?></td>
					<td align="center"><?php echo anchor('hospital/proses/'.$row->no_jaminan,'Proceed','class="btn btn-success"');?></td>
				</tr>
				<?php endforeach;?>
			</tbody>
		</thead>
	</table>
</div>