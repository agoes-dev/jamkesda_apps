<div class="table-responsive">
	<table id="dt_perawatan" class="table table-bordered table-hover">
		<thead align="center">
			<tr>
				<td>No</td>
				<td>No Jaminan</td>
				<td>Nama Peserta</td>
				<td>No NIK</td>
				<td>Selesai Dirawat</td>
				<td>Resume Medis</td>
				<td>Status</td>
				<td>Action</td>
			</tr>
		</thead>
		<?php 
			$no=0;
		?>
		<tbody align="center">
			<?php foreach ($perawatan as $row):?>
				<tr>
					<td><?php echo ++$no;?></td>
					<td><?php echo $row->no_jaminan;?></td>
					<td><?php echo $row->nm_peserta;?></td>
					<td><?php echo $row->nik_peserta;?></td>
					<td><?php echo date('d M Y',strtotime($row->tgl_selesai));?></td>
					<td><?php echo anchor($row->kwitansi,' ','class="span glyphicon glyphicon-eye-open"');?></td>
					<?php 
						if($row->status == 'claimed'){
							echo "<td>Accepted</td>";
							echo "<td>None</td>";
													
						}else{
							echo "<td>Sending</td>";
							echo "<td>".anchor('hospital/edit/'.$row->id_biaya,' ','class="span glyphicon glyphicon-pencil"')."</td>";
						}
					?>
				</tr>
		<?php endforeach;?>
		</tbody>
	</table>
</div>