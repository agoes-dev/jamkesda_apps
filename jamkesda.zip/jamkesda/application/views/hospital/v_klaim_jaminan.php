<h4>Data Perawatan</h4>
<div class="col-md-4">
<?php echo form_open_multipart('hospital/send_biaya');?>
	<label>No Jaminan</label>
	<?php echo form_input('no_jaminan',$jaminan->no_jaminan,'class="form-control" readonly');?>
	<br>
	<label>Upload Resume Medis</label>
	<?php echo form_upload('userfile');?>
	<br>
	<?php echo form_submit('submit','Submit','class="btn btn-success"');?>
	<?php echo anchor('hospital/newJaminan/'.$this->session->userdata('id_user'),'Cancel','class="btn btn-warning"');?><br><br>
	<?php echo form_close();?>

		<?php echo $error;?>
		<?php if (validation_errors() == FALSE){
                    echo "";
                }else{
                    echo "<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".validation_errors()."</strong>
                    </div>";
                };?>
</div>