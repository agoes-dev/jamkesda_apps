<!--<div class="container">	
	<div class="col-lg-4 col-sm-12" align="center">
		<div id="page-wrapper">
<h3>Welcome to E-Jamkesda</h3>
				<h4>Please Sign In</h4>
			<br>
			<?php echo form_open('login/action');?>
			<?php echo form_input('userid','','class="form-control" required placeholder="User ID"');?>
			<br>
			<?php echo form_password('password','','class="form-control" required placeholder="Password"');?>
			<br>
				<select name="level" class="form-control" required>
					<option value="" selected>Login As</option>
					<option value="hospital">Rumah Sakit</option>
					<option value="dinkes">Dinas Kesahatan</option>
				</select>
			<br>
			<?php echo form_submit('submit','Login','class="btn btn-success"');?>
			<?php echo form_reset('reset','Reset','class="btn btn-warning"');?>	
			<?php echo form_close();?>
			<?php echo "<strong>".$error."<strong>";?>
			</div>
		
		</div>	
	</div>
</div-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $title;?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>application/views/admin/css/bootstrap.min.css">
    <link href="<?php echo base_url(); ?>application/views/admin/css/sb-admin.css" rel="stylesheet">
</head>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title"><h4><center>JAMKESDA</center></h4></h3>
                    </div>
                    <?php echo form_open('login/action');?>
                    <div class="panel-body">
                        <form role="form">
                            <fieldset>
                                <div class="form-group">
                                    <?php echo form_input('userid','','class="form-control" placeholder="User ID" required');?>
                                </div>
                                <div class="form-group">
                                    <?php echo form_password('password','','class="form-control" placeholder="Password" required');?>
                                </div>
                                <div class="form-group">
                            		<select name="level" class="form-control" required>
										<option value="" selected>Login As</option>
										<option value="hospital">Rumah Sakit</option>
										<option value="dinkes">Dinas Kesahatan</option>
									</select>
                                </div>
                                <?php echo form_submit('submit','Login','class="btn btn-lg btn-success btn-block"');?>
                                <?php
                                	if(is_null($error)){
                                		echo "";
                                	}else{
                                		echo "<br><center><strong>".$error."</strong></center>";	
                                	}
                                ?>
                            </fieldset>
                        </form>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

