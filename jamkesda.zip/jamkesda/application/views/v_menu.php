<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title;?></title>
</head>
	<body>
		<ul>
			<a href="<?php echo base_url();?>petugas">Home</a>
			<a href="<?php echo base_url();?>petugas/add">Tambah Pasien</a>
			<a href="<?php echo base_url();?>petugas/list_pasien">Data Pasien</a>
			<a href="<?php echo base_url();?>klaim">Data Klaim</a>
			<a href="<?php echo base_url();?>report">Report</a>
			<a href="<?php echo base_url();?>logout">Logout</a>
		</ul>
	</body>
</html>