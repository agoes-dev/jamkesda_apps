<div align="center">
	<?php echo anchor('chart','Grafik Berdasarkan Range Biaya','class="btn"');?>
	<?php echo anchor('chart/grafik_jk','Grafik Berdasarkan Jenis Kelamin','class="btn"');?>
</div><br><br>