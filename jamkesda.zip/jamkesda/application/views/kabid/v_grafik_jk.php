<style>
  #chart_biaya
  {
   z-index:-10;
  }
   
</style>

<br>
<br>
<div id="chart_jk">
  
</div>

<script src="<?php echo base_url();?>assets/highcharts/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/highcharts/highchart.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/highcharts/modules/exporting.js" type="text/javascript"></script>


<script type="text/javascript">
jQuery(function(){
 new Highcharts.Chart({
  chart: {
   renderTo: 'chart_jk',
   type: 'pie',
  },
  title: {
   text: 'Jamkesda <?php echo date('Y');?>',
   x: -20
  },
  subtitle: {
   text: 'Grafik Peserta Berdasarkan Jenis Kelamin',
   x: -20
  },
   tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
  xAxis: {
   categories: ['Biaya Perawatan']
  },
  yAxis: {
   title: {
    text: 'Peserta Jamkesda (Orang)'
   }
  },
  series: [{
            name: 'Jenis Kelamin',
            colorByPoint: true,
            data: [{
                name: 'Laki-Laki',
                y: <?php echo json_encode($male);?>
            }, {
                name: 'Perempuan',
                y: <?php echo json_encode($female);?>,
            }]
        }]
 });
}); 
</script>