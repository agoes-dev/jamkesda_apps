<div class="table table-responsive">
<?php echo anchor('kabid/export','Export Excel','class="btn btn-success"');?>
<br><br>
	<table id="biaya" class="table table-bordered" >
		<thead align="center">
			<tr>
			<td>No</td>
			<td>Kode Rumah Sakit</td>
			<td>No Jaminan</td>
			<td>Selesai Dirawat</td>
			<td>Total Biaya</td>
			<td>Kwitansi</td>
		</tr>
		</thead>

		<?php
		$no = 0;
		?>
		
		<tbody>	
		<?php foreach ($biaya as $row) :?>
			<tr>
				<td><?php echo ++$no;?></td>
				<td><?php echo $row->nm_hospital;?></td>
				<td><?php echo $row->no_jaminan;?></td>
				<td><?php echo date('d M Y', strtotime($row->tgl_selesai));?></td>
				<td><?php echo "Rp.".number_format($row->total_biaya,2);?></td>
				<td align="center"><?php echo anchor($row->kwitansi,' ','class="span glyphicon glyphicon-eye-open"');?></td>
			</tr>
		<?php endforeach;?>
		</tbody>
	</table>
</div>