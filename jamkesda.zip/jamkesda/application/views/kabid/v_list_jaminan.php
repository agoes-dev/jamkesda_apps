<div class="table-responsive col-lg-12">
<?php echo anchor('kabid/export_jaminan','Export Excel','class="btn btn-success"');?>
<br><br>
	<table id="jaminan" class="table table-bordered table-hover">
		<thead align="center">
			<tr>
				<td>No</td>
				<td>No Jaminan</td>
				<td>Rumah Sakit</td>
				<td>Tgl Permohonan</td>
				<td>Nama Peserta</td>
				<td>NIK Peserta</td>
				<td>Jenis Kelamin</td>
				<td>Tempat Lahir</td>
				<td>Tanggal Lahir</td>
				<td>status Kawin</td>
				<td>Alamat</td>
				<td>RT</td>
				<td>RW</td>
				<td>Kecamatan</td>
				<td>Desa</td>
				<td>Diagnosa</td>
				<td>SKKM</td>
			</tr>	
		</thead>
	<?php
		$no=0;
	?>
		<tbody>
			<?php foreach ($jaminan as $row):?>
			<tr>
				<td><?php echo ++$no;?></td>
				<td><?php echo $row->no_jaminan;?></td>
				<td><?php echo $row->nm_hospital;?></td>
				<td><?php echo date('d M Y', strtotime($row->tgl_permohonan)) ;?></td>	
				<td><?php echo $row->nm_peserta;?></td>
				<td><?php echo $row->nik_peserta;?></td>
				<?php 
					if($row->jk == 1){
						echo "<td>Laki-laki</td>";
					}else{
						echo "<td>Perempuan</td>";
					}
				?>
				<td><?php echo ucfirst($row->tmp_lahir);?></td>
				<td><?php echo date('d M Y', strtotime($row->tgl_lahir));?></td>
				<?php 
					if($row->status_kawin == 1){
						echo "<td>Belum Menikah</td>";
					}elseif ($row->status_kawin == 2) {
						echo "<td>Menikah</td>";
					}else if($row->status_kawin == 3){
						echo "<td>Cerai</td>";
					}else{
						echo "<td>Tidak Menikah</td>";
					}
				?>
				<td><?php echo $row->alamat;?></td>
				<td><?php echo $row->rt;?></td>
				<td><?php echo $row->rw;?></td>
				<td><?php echo $row->kecamatan;?></td>
				<td><?php echo $row->desa;?></td>
				<td><?php echo $row->diagnosis;?></td>
				<td align="center"><?php echo anchor($row->skkm_dinsos,' ','class="span glyphicon glyphicon-eye-open"');?></td>
			</tr>	
			<?php endforeach;?>
		</tbody>
	</table>	
</div>
