<?php
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=report.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
?>

<table border="1">
		<h3 align="center">Laporan Biaya Perawatan Jamkesda Tahun <?php echo date('Y');?></h3>
	<tr align="center">

		<td><strong>No</strong></td>
		<td><strong>No Jaminan</strong></td>
		<td><strong>Rumah Sakit</strong></td>
		<td><strong>Nama Peserta</strong></td>
		<td><strong>Total Biaya</strong></td>
	</tr>
	<?php 
		$no=0;
	?>
	<?php foreach ($biaya as $row):?>
	<tr>
		<td><?php echo ++$no;?></td>
		<td><?php echo $row->no_jaminan;?></td>
		<td><?php echo $row->nm_hospital;?></td>
		<td><?php echo $row->nm_peserta;?></td>
		<td><?php echo number_format($row->total_biaya,2);?></td>		
	</tr>
	
<?php endforeach;?>
<tr>
	<td colspan="4" align="center">Grand Total</td>
	<td>
		<strong>Rp. <?php echo number_format($grand_total->total_biaya,2);?></strong>
	</td>
</tr>
</table>