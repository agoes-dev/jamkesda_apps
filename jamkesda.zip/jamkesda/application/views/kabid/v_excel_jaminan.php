<?php
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=report.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
?>
<div>
	<table border="1">
		<h2 align="center">Laporan Biaya Perawatan Jamkesda Tahun <?php echo date('Y');?></h2>
			<tr align="center">
				<td><strong>No</strong></td>
				<td><strong>No Jaminan</strong></td>
				<td><strong>Rumah Sakit</strong></td>
				<td><strong>Tgl Permohonan</strong></td>
				<td><strong>Nama Peserta</strong></td>
				<td><strong>NIK Peserta</strong></td>
				<td><strong>Jenis Kelamin</strong></td>
				<td><strong>Tempat Lahir</strong></td>
				<td><strong>Tanggal Lahir</strong></td>
				<td><strong>status Kawin</strong></td>
				<td><strong>Alamat</strong></td>
				<td><strong>RT</strong></td>
				<td><strong>RW</strong></td>
				<td><strong>Kecamatan</strong></td>
				<td><strong>Desa</strong></td>
				<td><strong>Diagnosa</strong></td>
			</tr>	
		<?php
			$no=0;
		?>
		<?php foreach ($jaminan as $row):?>
			<tr align="left">
				<td><?php echo ++$no;?></td>
				<td><?php echo $row->no_jaminan;?></td>
				<td><?php echo $row->nm_hospital;?></td>
				<td><?php echo date('d/m/Y', strtotime($row->tgl_permohonan)) ;?></td>	
				<td><?php echo $row->nm_peserta;?></td>
				<td><?php echo "'".$row->nik_peserta;?></td>
				<?php 
					if($row->jk == 1){
						echo "<td>Laki-laki</td>";
					}else{
						echo "<td>Perempuan</td>";
					}
				?>
				<td><?php echo ucfirst($row->tmp_lahir);?></td>
				<td><?php echo date('d-m-Y', strtotime($row->tgl_lahir));?></td>
				<?php 
					if($row->status_kawin == 1){
						echo "<td>Belum Menikah</td>";
					}elseif ($row->status_kawin == 2) {
						echo "<td>Menikah</td>";
					}else if($row->status_kawin == 3){
						echo "<td>Cerai</td>";
					}else{
						echo "<td>Tidak Menikah</td>";
					}
				?>
				<td><?php echo $row->alamat;?></td>
				<td><?php echo $row->rt;?></td>
				<td><?php echo $row->rw;?></td>
				<td><?php echo $row->kecamatan;?></td>
				<td><?php echo $row->desa;?></td>
				<td><?php echo $row->diagnosis;?></td>
			</tr>	
			<?php endforeach;?>
	</table>	
</div>
