<?php 
class Jaminan extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('dinkes_model'));

		if($this->session->userdata('level') != 'petugas'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Data Peserta Jamkesda";
		$data['jaminan']=$this->dinkes_model->get_all_jaminan()->result();

		$data['error']="";
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_list_jaminan',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function dirawat(){
		$data['title']="Data Peserta yang Masih di rawat";
		$data['jaminan']=$this->dinkes_model->get_jaminan_rawat()->result();

		$data['error']="";
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_list_jaminan',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function edit($id){
		$data['error']="";
		$data['option_hospital']=$this->dinkes_model->get_rs_list();
		$data['option_kecamatan']=$this->dinkes_model->get_kec_list();
		$data['jaminan']=$this->dinkes_model->edit_jaminan_by_id($id)->row();
		$data['title']="Edit Jaminan ".$data['jaminan']->no_jaminan;
 
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_edit_pasien',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function update(){
		$data['option_hospital']=$this->dinkes_model->get_rs_list();
		$data['option_kecamatan']=$this->dinkes_model->get_kec_list();
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('hospital','Rumah Sakit','required');
		$this->form_validation->set_rules('nama_pasien','Nama Pasien','required');
		$this->form_validation->set_rules('nik_pasien','NIK','required|numeric');
		$this->form_validation->set_rules('jk','Jenis Kelamin','required');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tanggal_lahir','Tanggal Lahir','required');
		//$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('alamat_pasien','Alamat Pasien','required');
		$this->form_validation->set_rules('rt','RT','required|integer');
		$this->form_validation->set_rules('rw','RW','required|integer');
		$this->form_validation->set_rules('kecamatan','Kecamatan','required|is_natural');
		$this->form_validation->set_rules('desa','Desa','required|is_natural');
		$this->form_validation->set_rules('diagnosis','Diagnosis','required');


		if( $this->form_validation->run() == FALSE){
			$data['error']="";
			$id=$this->input->post('id');
			$data['jaminan']=$this->dinkes_model->edit_jaminan_by_id($id)->row();
			$data['title']="Edit Jaminan ".$data['jaminan']->no_jaminan;

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_edit_pasien',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{

			if(is_null($this->input->post('hospital_baru'))){
				$rumahsakit=$this->input->post('hospital');
			}else{
				$rumahsakit=$this->input->post('hospital');
			}

			if(is_null($this->input->post('kecamatan_baru'))){
				$id_kecamatan=$this->input->post('kecamatan');
			}else{
				$id_kecamatan=$this->input->post('kecamatan');
			}

			if(is_null($this->input->post('desa_baru'))){
				$id_desa=$this->input->post('desa');
			}else{
				$id_desa=$this->input->post('desa');
			}

			if(is_null($this->input->post('status_baru'))){
				$status=$this->input->post('status');
			}else{
				$status=$this->input->post('status');
			}

			if(empty($_FILES['gambar']['name'])){
				$pict=$this->input->post('skkm');
			}else if(!empty($_FILES['gambar']['name'])){
				$config['allowed_types']="jpg|jpeg|png";
				$config['remove_spaces']=TRUE;
				$config['encrypt_name']=TRUE;
				$config['upload_path']=FCPATH.'file_upload/';
				$config['max_size']=2048;

				$this->load->library('upload');
				$this->upload->initialize($config);

				if(!$this->upload->do_upload('gambar')){
					$data['error']=$this->upload->display_errors();	
					$id=$this->input->post('id');
					$data['jaminan']=$this->dinkes_model->edit_jaminan_by_id($id)->row();
					$data['title']="Edit Jaminan ".$data['jaminan']->no_jaminan;

					$this->load->view('dinkes/bg_atas',$data);
					$this->load->view('dinkes/bg_menu',$data);
					$this->load->view('dinkes/v_edit_pasien',$data);
					$this->load->view('dinkes/bg_bawah',$data);
					$pict="";
				}else{
					$this->upload->do_upload('gambar');

					$data_image=$this->upload->data('file_name');
					$location=base_url().'file_upload/';
					$pict=$location.$data_image;
				}
			}else{
				$pict=$this->input->post('skkm');
			}

			$no_jaminan=$this->input->post('no_jaminan',TRUE);
			$nama_pasien=$this->input->post('nama_pasien',TRUE);
			$nik_pasien=$this->input->post('nik_pasien',TRUE);
			$jk=$this->input->post('jk',TRUE);
			$tmp_lahir=$this->input->post('tempat_lahir',TRUE);
			$tgl_lahir=$this->input->post('tanggal_lahir',TRUE);
			//$status=$this->input->post('status',TRUE);
			$alamat_pasien=$this->input->post('alamat_pasien',TRUE);
			$rt=$this->input->post('rt');
			$rw=$this->input->post('rw');
			$diagnosis=$this->input->post('diagnosis',TRUE);
			
			//ambil data image

			/*$this->upload->do_upload('gambar1');			
			$data_image=$this->upload->data('file_name');
			//$data_name=$data_image['file_name'];
			$location=base_url().'file_upload/';
			$pict=$location.$data_image;

			$this->upload->do_upload('gambar2');
			$data_image2=$this->upload->data('file_name');
			//$data_name2=$data_image2['file_name'];
			$location2=base_url().'file_upload/';
			$pict2=$location2.$data_image2;*/
			
			$jaminan=array(
				'id_hospital' => $rumahsakit,
				'nm_peserta' => $nama_pasien,
				'nik_peserta' => $nik_pasien,
				'jk' => $jk,
				'tmp_lahir' => $tmp_lahir,
				'tgl_lahir' => date('Y-m-d',strtotime($tgl_lahir)),
				'status_kawin' => $status,
				'alamat' => $alamat_pasien,
				'rt' => $rt,
				'rw' => $rw,
				'id_kecamatan' => $id_kecamatan,
				'id_desa' => $id_desa,
				'diagnosis' => $diagnosis,
				'skkm_dinsos'	=> $pict,
				'tgl_permohonan' => date('Y-m-d')
			);
			/*$pasien=array(
				'nik_pasien' => $nik_pasien,
				'nm_pasien' => $nama_pasien,
				'jk' => $jk,
				'tempat_lahir' => $tmp_lahir,
				'tanggal_lahir' => date('Y-m-d',strtotime($tgl_lahir)),
				'alamat_pasien' => $alamat_pasien
				);
			//$this->dinkes_model->save_jaminan($jaminan);
			//$this->dinkes_model->save_pasien($pasien);
			echo print_r($jaminan);

			*/
			$this->dinkes_model->update_jaminan($jaminan,$no_jaminan);

			$id=$this->input->post('id');
			$data['jaminan']=$this->dinkes_model->edit_jaminan_by_id($id)->row();
			$data['title']="Edit Jaminan ".$data['jaminan']->no_jaminan;

			$data['error']="Data Berhasil Di Update";

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_edit_pasien',$data);
			$this->load->view('dinkes/bg_bawah',$data);

			//echo print_r($jaminan);
		}
	}
	function del_pasien(){
		$id=$this->uri->segment(3);

		$this->dinkes_model->del_pasien_by_id($id);
		$data['error']="Data Berhasil di Hapus";
	}
	function view(){
		$id_user=$this->session->userdata('id_user');
		$data['user']=$this->dinkes_model->getUser($id_user)->row();

		$no_jaminan=$this->uri->segment(3);
		$data['jaminan']=$this->dinkes_model->get_data($no_jaminan)->row();
		$data['title']=$data['jaminan']->no_jaminan;

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_data_pasien',$data);
		$this->load->view('dinkes/bg_bawah',$data);
		
	}
	function delete(){
		$id=$this->uri_segment(3);

		$this->petugas_model->del_pasien_by_id($id);
		$data['error']="Data Berhasil di Hapus";
		$this->list_pasien($data);
	}
}//end of controllers