<style>
  #chart_biaya
  {
   z-index:-10;
  }
   
</style>
<div id="chart_biaya">

</div><br>
<br>

<script src="<?php echo base_url();?>assets/highcharts/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/highcharts/highchart.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/highcharts/modules/exporting.js" type="text/javascript"></script>


<script type="text/javascript">
jQuery(function(){
 new Highcharts.Chart({
  chart: {
   renderTo: 'chart_biaya',
   type: 'column',
  },
  title: {
   text: 'Jamkesda <?php echo date('Y');?>',
   x: -20
  },
  subtitle: {
   text: 'Grafik Biaya Peserta',
   x: -20
  },
  xAxis: {
   categories: ['Biaya Perawatan']
  },
  yAxis: {
   title: {
    text: 'Peserta Jamkesda (Orang)'
   }
  },
  series: [{
    name: ' < Rp. 1.000.000,00',
    data: <?php echo json_encode($biaya1); ?>
  },
  {
    name: 'Rp. 1.000.000,00 - Rp.5.000.000,00',
    data: <?php echo json_encode($biaya2); ?>
  },
  {
    name: '> Rp.5000.000,00',
    data: <?php echo json_encode($biaya3); ?>
  }

  ]
 });
}); 
</script>



