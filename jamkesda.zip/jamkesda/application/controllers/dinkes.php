<?php  defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Dinkes extends Ci_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('dinkes_model','user_model'));
		$this->load->helper(array('url','form','html','file'));

		if($this->session->userdata('level') != 'petugas'){
			redirect('login');
		}
	}
	function index(){ 
		$data['title']="Dinas Kesehatan Kab. Bogor";
		
		$data['peserta']=$this->dinkes_model->get_data_peserta()->num_rows();
		$data['dirawat']=$this->dinkes_model->get_data_rawat()->num_rows();
		$data['hospital']=$this->dinkes_model->get_data_hospital()->num_rows();
		
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_dinkes',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function claim_in(){
		$data['klaim']=$this->dinkes_model->get_data_klaim()->num_rows();

		$this->load->view('dinkes/v_klaim',$data);
	}
	function add(){
		$data['option_hospital']=$this->dinkes_model->get_rs_list();
		$data['option_kecamatan']=$this->dinkes_model->get_kec_list();
		$data['title']="Tambah Peserta";
		
		//nomor jaminan secara urut
		$month=date('m');
		$year=date('Y');
		//mengubah angka bulan menjadi angka romawi
		if($month == "1"){
			$bln = "I";
		}elseif ($month == "2") {
			$bln ="II";
		}elseif ($month == "3") {
			$bln = "III";
		}elseif ($month == "4") {
			$bln = "IV";
		}elseif ($month == "5") {
			$bln = "V";
		}elseif ($month == "6") {
			$bln = "VI";
		}elseif ($month == "7") {
			$bln = "VII";
		}elseif ($month == "8") {
			$bln = "VII";
		}elseif ($month == "9") {
			$bln = "IX";
		}else{
			$bln = "X";
		}
		
		$no=$this->dinkes_model->get_last_number()->num_rows();
		if($no == ''){
			$data['no_jaminan']="P0001/$bln/Promkes-SDK/$year";
		}else{
			$no=$this->dinkes_model->get_last_number()->row();
			$maxID = $no->no_jaminan;
			$no_urut = (int)substr($maxID,1,4);
			$no_urut++;
			$newID = "P".sprintf("%04s",$no_urut);
			$data['no_jaminan']="$newID/$bln/Promkes-SDK/$year";
		}
		$data['error']="";

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_add_pasien',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function select_desa(){
		$data['option_desa']=$this->dinkes_model->get_desa_list();
		$this->load->view('dinkes/v_desa',$data);	
	}
	function save_pasien(){
		$data['option_hospital']=$this->dinkes_model->get_rs_list();
		$data['option_kecamatan']=$this->dinkes_model->get_kec_list();
		
		$this->load->library('form_validation');
		$this->form_validation->set_rules('hospital','Rumah Sakit','required');
		$this->form_validation->set_rules('nama_pasien','Nama Pasien','required');
		$this->form_validation->set_rules('nik_pasien','NIK','required|numeric');
		$this->form_validation->set_rules('jk','Jenis Kelamin','required');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tanggal_lahir','Tanggal Lahir','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('alamat_pasien','Alamat Pasien','required');
		$this->form_validation->set_rules('rt','RT','required|integer');
		$this->form_validation->set_rules('rw','RW','required|integer');
		$this->form_validation->set_rules('kecamatan','Kecamatan','required|is_natural');
		$this->form_validation->set_rules('desa','Desa','required|is_natural');
		$this->form_validation->set_rules('diagnosis','Diagnosis','required');
		
		//$this->form_validation->set_rules('gambar1','SKKM DINSOS','required');
		if(empty($_FILES['gambar1']['name'])){
			$this->form_validation->set_rules('gambar1','SKKM DINSOS','required');
		}
		//upload surat SKKM 
		$config['max_size']=2048;
		$config['allowed_types']='png|jpeg|jpg';
		$config['remove_spaces']=TRUE;
		$config['encrypt_name']=TRUE;
		//$config['overwrite']=TRUE;
		$config['upload_path']=FCPATH.'file_upload/';

		
		$this->load->library('upload');
		$this->upload->initialize($config);

		if( $this->form_validation->run() == FALSE){
			
			$data['error']="";
			$data['title']="Add Data Pasien";
				//nomor jaminan secara urut
			$month=date('m');
			$year=date('Y');
			//mengubah angka bulan menjadi angka romawi
			if($month == "1"){
				$bln = "I";
			}elseif ($month == "2") {
				$bln ="II";
			}elseif ($month == "3") {
				$bln = "III";
			}elseif ($month == "4") {
				$bln = "IV";
			}elseif ($month == "5") {
				$bln = "V";
			}elseif ($month == "6") {
				$bln = "VI";
			}elseif ($month == "7") {
				$bln = "VII";
			}elseif ($month == "8") {
				$bln = "VII";
			}elseif ($month == "9") {
				$bln = "IX";
			}else{
				$bln = "X";
			}

			$no=$this->dinkes_model->get_last_number()->num_rows();
		if($no == 0){
			$data['no_jaminan']="P0001/$bln/Promkes-SDK/$year";
		}else{
			$no=$this->dinkes_model->get_last_number()->row();
			$maxID = $no->no_jaminan;
			$no_urut = (int)substr($maxID,1,4);
			$no_urut++;
			$newID = "P".sprintf("%04s",$no_urut);
			$data['no_jaminan']="$newID/$bln/Promkes-SDK/$year";
		}

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_add_pasien',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{

			$month=date('m');
			$year=date('Y');
			//mengubah angka bulan menjadi angka romawi
			if($month == "1"){
				$bln = "I";
			}elseif ($month == "2") {
				$bln ="II";
			}elseif ($month == "3") {
				$bln = "III";
			}elseif ($month == "4") {
				$bln = "IV";
			}elseif ($month == "5") {
				$bln = "V";
			}elseif ($month == "6") {
				$bln = "VI";
			}elseif ($month == "7") {
				$bln = "VII";
			}elseif ($month == "8") {
				$bln = "VII";
			}elseif ($month == "9") {
				$bln = "IX";
			}else{
				$bln = "X";
			}

			$no=$this->dinkes_model->get_last_number()->num_rows();
		if($no == 0){
			$data['no_jaminan']="P0001/$bln/Promkes-SDK/$year";
		}else{
			$no=$this->dinkes_model->get_last_number()->row();
			$maxID = $no->no_jaminan;
			$no_urut = (int)substr($maxID,1,4);
			$no_urut++;
			$newID = "P".sprintf("%04s",$no_urut);
			$data['no_jaminan']="$newID/$bln/Promkes-SDK/$year";
		}

			$no_jaminan=$this->input->post('no_jaminan',TRUE);
			$nama_pasien=$this->input->post('nama_pasien',TRUE);
			$nik_pasien=$this->input->post('nik_pasien',TRUE);
			$jk=$this->input->post('jk',TRUE);
			$tmp_lahir=$this->input->post('tempat_lahir',TRUE);
			$tgl_lahir=$this->input->post('tanggal_lahir',TRUE);
			$status=$this->input->post('status',TRUE);
			$alamat_pasien=$this->input->post('alamat_pasien',TRUE);
			$rt=$this->input->post('rt');
			$rw=$this->input->post('rw');
			$rumahsakit=$this->input->post('hospital',TRUE);
			$diagnosis=$this->input->post('diagnosis',TRUE);
			$id_kecamatan=$this->input->post('kecamatan',TRUE);
			$id_desa=$this->input->post('desa',TRUE);

			//ambil data image
			$this->upload->do_upload('gambar1');			
			$data_image=$this->upload->data('file_name');
			//$data_name=$data_image['file_name'];
			$location=base_url().'file_upload/';
			$pict1=$location.$data_image;

			$this->upload->do_upload('gambar2');
			$data_image2=$this->upload->data('file_name');
			//$data_name2=$data_image2['file_name'];
			$location2=base_url().'file_upload/';
			$pict2=$location2.$data_image2;
			
			$jaminan=array(
				'no_jaminan' => $no_jaminan,
				'id_hospital' => $rumahsakit,
				'nm_peserta' => $nama_pasien,
				'nik_peserta' => $nik_pasien,
				'jk' => $jk,
				'tmp_lahir' => $tmp_lahir,
				'tgl_lahir' => date('Y-m-d',strtotime($tgl_lahir)),
				'status_kawin' => $status,
				'alamat' => $alamat_pasien,
				'rt' => $rt,
				'rw' => $rw,
				'id_kecamatan' => $id_kecamatan,
				'id_desa' => $id_desa,
				'diagnosis' => $diagnosis,
				'skkm_dinsos'	=> $pict1,
				'tgl_permohonan' => date('Y-m-d'),
				'status' => 'new'
			);
			$pasien=array(
				'nik_pasien' => $nik_pasien,
				'nm_pasien' => $nama_pasien,
				'jk' => $jk,
				'tempat_lahir' => $tmp_lahir,
				'tanggal_lahir' => date('Y-m-d',strtotime($tgl_lahir)),
				'alamat_pasien' => $alamat_pasien
				);
			$this->dinkes_model->save_jaminan($jaminan);
			//$this->dinkes_model->save_pasien($pasien);
			//echo print_r($jaminan);

			$data['error']="Data Berhasil Di Simpan";
			$data['title']="Add Data Penerima Jaminan";

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_add_pasien',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}
	}
}//end of controller