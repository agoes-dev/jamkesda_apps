<?php
/**
* 
*/
class User extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','html','url'));
		$this->load->model(array('user_model'));

		if($this->session->userdata('level') != 'petugas'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Data User";
		$data['user']=$this->user_model->get_all_user()->result();

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_data_user',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function add(){
		$data['title']="Tambah User";
		$data['error']="";

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_add_user',$data);
		$this->load->view('dinkes/bg_bawah',$data);	
	}
	function save(){
		$this->load->library('form_validation');

		$this->form_validation->set_rules('userid','User ID','required');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('level','Level','required');

		if($this->form_validation->run() == FALSE){
			$data['title']="Tambah User";
			$data['error']="";

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_add_user',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{
			$userid=$this->input->post('userid');
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$level=$this->input->post('level');

			$user = array(
				'id_user' => $userid,
				'nm_user' => $username,
				'password' => md5($password),
				'level' => $level 
			);

			$this->user_model->saveUser($user);

			$data['title']="Tambah User";
			$data['error']="<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Data Berhasil Di Tambah !</strong></div>";
			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_add_user',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}
	}
	function edit($id){
		$data['error']="";
		$data['user']=$this->user_model->get_user_by_id($id)->row();
		$data['title']="Edit Data User ".$data['user']->nm_user;

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_edit_user',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function update(){
		$this->load->library('form_validation');

		$this->form_validation->set_rules('userid','User ID','required');
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		$id=$this->input->post('id');
		if($this->form_validation->run() == FALSE){
			$data['error']="";
			$data['user']=$this->user_model->get_user_by_id($id)->row();
			$data['title']="Edit Data User";
			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_edit_user',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{
			$userid=$this->input->post('userid');
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$level=$this->input->post('level');

			$user = array(
				'id_user' => $userid,
				'nm_user' => $username,
				'password' => md5($password),
				'level' => $level
			);
			$this->user_model->updateUser($user,$id);

			$data['error']="<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;<span></button><strong>Data Berhasil Di Update !</strong></div>";

			$data['user']=$this->user_model->get_user_by_id($id)->row();
			$data['title']="Edit Data User";
			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_edit_user',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}
	}
	function delete($id){
		$this->user_model->del_by_id($id);
		redirect('user');
	}
}//end of controller