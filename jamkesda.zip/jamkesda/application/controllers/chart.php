<?php
/**
* 
*/
class Chart extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('chart_model');
		$this->load->helper(array('url','html','form'));
		if($this->session->userdata('level') != 'kabid'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Grafik Jamkesda Tahun ".date('Y');
		
			//chart berdasarkan range biaya
			$data['biaya1'][]=(int)$this->chart_model->report_biaya1()->num_rows();
			$data['biaya2'][]=(int)$this->chart_model->report_biaya2()->num_rows();
			$data['biaya3'][]=(int)$this->chart_model->report_biaya3()->num_rows();

			//chart berdasarkan jk
			$data['male']=(int)$this->chart_model->get_data_by_male()->num_rows();
			$data['female']=(int)$this->chart_model->get_data_by_female()->num_rows();

			$this->load->view('kabid/bg_atas',$data);
			$this->load->view('kabid/bg_menu',$data);
			$this->load->view('kabid/v_option_grafik',$data);
			$this->load->view('kabid/v_grafik',$data);
			$this->load->view('kabid/bg_bawah',$data);
	}
	function grafik_jk(){
		$data['title']="Grafik Jamkesda Tahun ".date('Y');
		$data['male']=(int)$this->chart_model->get_data_by_male()->num_rows();
		$data['female']=(int)$this->chart_model->get_data_by_female()->num_rows();

		$this->load->view('kabid/bg_atas',$data);
			$this->load->view('kabid/bg_menu',$data);
			$this->load->view('kabid/v_option_grafik',$data);
			$this->load->view('kabid/v_grafik_jk',$data);
			$this->load->view('kabid/bg_bawah',$data);

	}
}//end of controller