<?php  defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Rumahsakit extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('rs_model'));
		$this->load->helper(array('url','form','html'));

		if($this->session->userdata('level') != 'petugas'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Data Hospital";
		$data['hospital']=$this->rs_model->get_all_hospital()->result();
		$data['error']="";

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_list_hospital',$data);
		$this->load->View('dinkes/bg_bawah',$data);
	}
	function add(){
		$no=$this->rs_model->get_last_number()->num_rows();

		if($no == ''){
			$data['kode_rs']="RS001";
		}else{
			$no=$this->rs_model->get_last_number()->row();
			$maxID = $no->id_hospital;
			$no_urut = (int)substr($maxID, 2,3);
			$no_urut++;
			$newID = "RS".sprintf("%03s",$no_urut);
			$data['kode_rs']="$newID";
		}
		$data['title']="Add Hospital";
		$data['error']="";

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_add_hospital',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function save(){
		$data['error']="";
		$this->load->library('form_validation');

		$this->form_validation->set_rules('nm_hospital','Nama Rumah Sakit','required');
		$this->form_validation->set_rules('address','Alamat','required');
		$this->form_validation->set_rules('password','Password','required');

			if($this->form_validation->run() == FALSE){
				
			$no=$this->rs_model->get_last_number()->num_rows();

			if($no == ''){
				$data['kode_rs']="RS001";
			}else{
				$no=$this->rs_model->get_last_number()->row();
				$maxID = $no->id_hospital;
				$no_urut = (int)substr($maxID, 2,3);
				$no_urut++;
				$newID = "RS".sprintf("%03s",$no_urut);
				$data['kode_rs']="$newID";
			}
			$data['title']="Tambah Rumah Sakit";
			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/v_add_hospital',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{
			$id_hospital=$this->input->post('id_hospital');
			$nm_hospital=$this->input->post('nm_hospital');
			$address=$this->input->post('address');
			$password=$this->input->post('password');

			$hospital = array(
				'id_hospital' => $id_hospital,
				'nm_hospital' => $nm_hospital,
				'address' => $address,
				'password' => md5($password),
				'status' => '1'
			);
			$no=$this->rs_model->get_last_number()->num_rows();

			if($no == ''){
				$data['kode_rs']="RS001";
			}else{
				$no=$this->rs_model->get_last_number()->row();
				$maxID = $no->id_hospital;
				$no_urut = (int)substr($maxID, 2,3);
				$no_urut++;
				$newID = "RS".sprintf("%03s",$no_urut);
				$data['kode_rs']="$newID";
			}
			//echo print_r($hospital);
			$this->rs_model->saveHospital($hospital);
			redirect('rumahsakit');
		}
	}
	function edit($id){
		$data['error']="";
		$data['rs']=$this->rs_model->getName($id)->row();
		$data['title']="Edit Data Rumah Sakit ".$data['rs']->nm_hospital;
		
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_edit_hospital',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function update(){
		$id_hospital=$this->input->post('id_hospital');
		$nm_hospital=$this->input->post('nm_hospital');
		$address=$this->input->post('address');
		$password=$this->input->post('password');
		$status=$this->input->post('status');

		$hospital = array(
			'nm_hospital' => $nm_hospital,
			'address' => $address,
			'password' => md5($password),
			'status' => $status
		);
		$this->rs_model->updateHospital($hospital,$id_hospital);
		
		$data['error']="<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button><strong>Data Berhasil Di Update !</strong></div>";
		$data['rs']=$this->rs_model->getName($id_hospital)->row();
		$data['title']="Edit Data Rumah Sakit ".$data['rs']->nm_hospital;
		
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/v_edit_hospital',$data);
		$this->load->view('dinkes/bg_bawah',$data);

	}
}//end of controller