<?php
class Hospital extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('url','form','html'));
		$this->load->model('hospital_model');

		if($this->session->userdata('level') != 'hospital' AND 'petugas'){
			redirect('login');
		}
	}
	function index(){
		$id=$this->session->userdata('id_user');
		$data['title']=$this->session->userdata('username');
		$data['jaminan']=$this->hospital_model->get_new_jaminan($id)->num_rows();

		$this->load->view('hospital/bg_atas',$data);
		$this->load->view('hospital/bg_menu',$data);
		$this->load->view('hospital/v_hospital_page',$data);
		$this->load->view('hospital/bg_bawah',$data);
	}
	function jaminanbaru(){
		$id=$this->session->userdata('id_user');
		$data['title']=$this->session->userdata('username');
		$data['jaminan']=$this->hospital_model->get_new_jaminan($id)->num_rows();

		$this->load->view('hospital/v_newJaminan',$data);
	}
	function newJaminan($id){
		$data['title']="Data Pasien Penerima Bantuan";
		//$id=$this->session->userdata('id_user');
		//$data['user']=$this->hospital_model->get_username($id)->row();
		$data['jaminan']=$this->hospital_model->getJaminan($id)->result();
		$data['peserta']=$this->hospital_model->getJaminan($id)->num_rows();

		$this->load->view('hospital/bg_atas',$data);
		$this->load->view('hospital/bg_menu',$data);
		$this->load->view('hospital/v_data_jaminan',$data);
		$this->load->view('hospital/bg_bawah',$data);
	}
	function proses($id){
		$data['error']="";
		$id_user=$this->session->userdata('id_user');
		//$data['user']=$this->hospital_model->get_username($id)->row();
		$data['jaminan']=$this->hospital_model->getDetailJaminan($id,$id_user)->row();
		$data['title']=$data['jaminan']->no_jaminan;

		$this->load->view('hospital/bg_atas',$data);
		$this->load->view('hospital/bg_menu',$data);
		$this->load->view('hospital/v_klaim_jaminan',$data);
		$this->load->view('hospital/bg_bawah',$data);
	}
	function send_biaya(){
		$this->load->library('form_validation');

		$this->form_validation->set_rules('no_jaminan','No Jaminan','required');
		//$this->form_validation->set_rules('deskripsi','Deskripsi Perawatan','required');
		//$this->form_validation->set_rules('jenis_obat', 'Jenis Obat','required');
		//$this->form_validation->set_rules('tot_biaya','Total Biaya','required|integer');
		if(empty($_FILES['userfile']['name'])){
			$this->form_validation->set_rules('userfile','Kwitansi','required');
		}

		if($this->form_validation->run() == FALSE){
			$data['error']="";
			$id=$this->session->userdata('id_user');
			//$data['user']=$this->hospital_model->get_username($id)->row();
			$data['jaminan']=$this->hospital_model->getJaminan($id)->row();
			$data['title']=$data['jaminan']->no_jaminan;

			$this->load->view('hospital/bg_atas',$data);
			$this->load->view('hospital/bg_menu',$data);
			$this->load->view('hospital/v_klaim_jaminan',$data);
			$this->load->view('hospital/bg_bawah',$data);
		}else{
			$config['allowed_types']="jpg|jpeg|png";
			$config['upload_path']=FCPATH.'file_upload/';
			$config['remove_spaces']=TRUE;
			$config['encrypt_name']=TRUE;
			$config['max_sizes']=2048;

			$this->load->library('upload');
			$this->upload->initialize($config);

			if(!$this->upload->do_upload()){
				$data['error']="<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".$this->upload->display_errors()."</strong>
                    </div>";

				$id=$this->session->userdata('id_user');
				//$data['user']=$this->hospital_model->get_username($id)->row();
				$data['jaminan']=$this->hospital_model->getJaminan($id)->row();
				$data['title']=$data['jaminan']->no_jaminan;

				$this->load->view('hospital/bg_atas',$data);
				$this->load->view('hospital/bg_menu',$data);
				$this->load->view('hospital/v_klaim_jaminan',$data);
				$this->load->view('hospital/bg_bawah',$data);	
			}else{
				//$perawatan=$this->input->post('jenis_perawatan',TRUE);
				$no_jaminan=$this->input->post('no_jaminan',TRUE);
				$tgl_selesai=date('Y-m-d');
				$no_jaminan=$this->input->post('no_jaminan',TRUE);

				$dt_kwitansi=$this->upload->data();
				$nama_file=$dt_kwitansi['file_name'];
				$location=base_url().'file_upload/';
				$kwitansi=$location.$nama_file;

				$biaya = array(
					'id_hospital' => $this->session->userdata('id_user'),
					'no_jaminan' => $no_jaminan,
					'kwitansi' => $kwitansi,
					'tgl_selesai' => $tgl_selesai,
					'total_biaya' => '',
					'status' => 'new'
				);
				$this->hospital_model->save_biaya($biaya);
				//update status jaminan
				$status = array(
						'status' => 'done'
					);
				//echo var_dump($biaya);
				//echo var_dump($status);

				$this->hospital_model->updateStatusJaminan($status,$no_jaminan);
				redirect('hospital');
			}
		}
	}
	function listPerawatan($id){
		$data['title']="Data Perawatan";
		//$id=$this->session->userdata('id_user');
		$data['perawatan']=$this->hospital_model->get_data_perawatan($id)->result();

		$this->load->view('hospital/bg_atas',$data);
		$this->load->view('hospital/bg_menu',$data);
		$this->load->view('hospital/v_data_perawatan',$data);
		$this->load->view('hospital/bg_bawah',$data);
	}
	function edit($id){
		$data['title']="Edit Data";
		$data['error']="";
		$data['peserta']=$this->hospital_model->get_peserta_by_id($id)->row();

		$this->load->view('hospital/bg_atas',$data);
		$this->load->view('hospital/bg_menu',$data);
		$this->load->view('hospital/v_edit_klaim',$data);
		$this->load->view('hospital/bg_bawah',$data);
	}
	function update(){
		$this->load->library('form_validation');

		$this->form_validation->set_rules('no_jaminan','No Jaminan','required');
		if(empty($_FILES['userfile']['name'])){
			$this->form_validation->set_rules('userfile','Kwitansi','required');
		}

		$id=$this->input->post('id_biaya');
		$no_jaminan=$this->input->post('no_jaminan');
		$tgl_selesai=$this->input->post('tgl_selesai');

		if($this->form_validation->run() == FALSE){
			$data['title']="Edit Data";
			$data['error']="";
			$data['peserta']=$this->hospital_model->get_peserta_by_id($id)->row();

			$this->load->view('hospital/bg_atas',$data);
			$this->load->view('hospital/bg_menu',$data);
			$this->load->view('hospital/v_edit_klaim',$data);
			$this->load->view('hospital/bg_bawah',$data);
		}else{
			$config['allowed_types'] = 'jpg|jpeg|png';
			$config['encrypt_name'] = TRUE;
			$config['upload_path'] = FCPATH.'file_upload/';
			$config['remove_spaces'] = TRUE;

			$this->load->library('upload');
			$this->upload->initialize($config);

			if(!$this->upload->do_upload()){
				$data['error']="<div class='alert alert-warning alert-dismissible' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button>
                    <strong>".$this->upload->display_errors()."</strong>
                    </div>";

				$data['title']="Edit Data";
				$data['peserta']=$this->hospital_model->get_peserta_by_id($id)->row();

				$this->load->view('hospital/bg_atas',$data);
				$this->load->view('hospital/bg_menu',$data);
				$this->load->view('hospital/v_edit_klaim',$data);
				$this->load->view('hospital/bg_bawah',$data);
			}else{
				$dt_kwitansi=$this->upload->data();
				$nama_file=$dt_kwitansi['file_name'];
				$location=base_url().'file_upload/';
				$kwitansi=$location.$nama_file;

				$data = array(
					'kwitansi' => $kwitansi
				);
				$this->hospital_model->update_klaim($data,$id);
				redirect('hospital/listPerawatan/'.$this->session->userdata('id_user'));
			}
		}
	}//end of function
}//end of controllers