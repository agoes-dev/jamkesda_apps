<?php 
class Kabid extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url','html'));
		$this->load->model('kabid_model');

		if($this->session->userdata('level') != 'kabid'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Welcome Kabid";
		$data['peserta']=$this->kabid_model->get_data_peserta()->num_rows();
		$data['dirawat']=$this->kabid_model->get_dirawat()->num_rows();

		$this->load->view('kabid/bg_atas',$data);
		$this->load->view('kabid/bg_menu',$data);
		$this->load->view('kabid/v_statistik',$data);
		$this->load->view('kabid/bg_bawah',$data);
	}
	function jaminan(){
		$data['title']="Data Peserta Jamkesda";
		$data['jaminan']=$this->kabid_model->get_all_peserta()->result();

		$this->load->view('kabid/bg_atas',$data);
		$this->load->view('kabid/bg_menu',$data);
		$this->load->view('kabid/v_list_jaminan',$data);
		$this->load->view('kabid/bg_bawah',$data);
	}
	function biaya(){
		$data['title']="Daftar Biaya Perawatan";
		$data['biaya']=$this->kabid_model->get_all_biaya()->result();

		$this->load->view('kabid/bg_atas',$data);
		$this->load->view('kabid/bg_menu',$data);
		$this->load->view('kabid/v_list_biaya',$data);
		$this->load->view('kabid/bg_bawah',$data);
	}
	function export(){
		$data['grand_total']=$this->kabid_model->get_grand_total()->row();
		$data['biaya']=$this->kabid_model->get_all_biaya()->result();

		$this->load->view('kabid/v_excel',$data);	
	}
	function export_jaminan(){
		$data['jaminan']=$this->kabid_model->get_all_peserta()->result();

		$this->load->view('kabid/v_excel_jaminan',$data);		
	}
	function peserta(){
		$data['title']="Peserta Bulan ini";
		$data['peserta']=$this->kabid_model->get_data_peserta()->result();

		$this->load->view('kabid/bg_atas',$data);
		$this->load->view('kabid/bg_menu',$data);
		$this->load->view('kabid/v_peserta_bln_ini',$data);
		$this->load->view('kabid/bg_bawah',$data);
	}
}//end of controllers