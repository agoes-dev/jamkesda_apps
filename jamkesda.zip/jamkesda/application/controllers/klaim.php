<?php
/**
*  
*/
class Klaim extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form','html'));
		$this->load->model(array('klaim_model'));

		if($this->session->userdata('level') != 'petugas'){
			redirect('login');
		}
	}
	function index(){
		$data['title']="Data Klaim Rumah Sakit";
		$data['klaim']=$this->klaim_model->get_all_klaim_by_status()->result();

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/klaim/v_list_data_klaim',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function claim_in(){
		$data['title']="Klaim Biaya Perawatan Masuk";

		$data['klaim']=$this->klaim_model->get_klaim_by_id()->result();
		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/klaim/v_klaim',$data);
		$this->load->view('dinkes/bg_bawah',$data);	
	}
	function proceed($id){
		$data['error']="";
		$data['title']="Input Biaya Perawatan";
		$data['klaim']=$this->klaim_model->get_data_by_id($id)->row();

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu');
		$this->load->view('dinkes/klaim/v_input_biaya',$data);
		$this->load->view('dinkes/bg_bawah');
	}
	function insert(){
		$this->load->library('form_validation');
		$id=$this->input->post('id_biaya');

		$this->form_validation->set_rules('total_biaya','Total Biaya','required|numeric');

		if($this->form_validation->run() == FALSE){
			$data['title']="Input Biaya Perawatan";
			$data['error']="";
			$data['klaim']=$this->klaim_model->get_data_by_id($id)->row();

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu');
			$this->load->view('dinkes/klaim/v_input_biaya',$data);
			$this->load->view('dinkes/bg_bawah');
		}else{
			$id_biaya=$this->input->post('id_biaya');
			$no_jaminan=$this->input->post('no_jaminan');
			$id_hospital=$this->input->post('id_hospital');
			$tgl_selesai=$this->input->post('tgl_selesai');
			$biaya=$this->input->post('total_biaya');


			$update = array(
				'total_biaya' => $biaya, 
				'status' => 'claimed'
			);
			$this->klaim_model->update_klaim($update,$id_biaya);
			redirect('klaim');
		}
	}
	function edit($id){
		$data['title']="Edit Biaya";
		$data['error']="";
		$data['klaim']=$this->klaim_model->get_biaya_by_id($id)->row();

		$this->load->view('dinkes/bg_atas',$data);
		$this->load->view('dinkes/bg_menu',$data);
		$this->load->view('dinkes/klaim/v_edit_biaya',$data);
		$this->load->view('dinkes/bg_bawah',$data);
	}
	function update(){
		$id=$this->input->post('id_biaya');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('total_biaya','Total Biaya','required|numeric');

		if($this->form_validation->run() == FALSE ){
			$data['title']="Edit Biaya";
			$data['error']="";
			$data['klaim']=$this->klaim_model->get_biaya_by_id($id)->row();

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/klaim/v_edit_biaya',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}else{
			$id_biaya=$this->input->post('id_biaya');
			$biaya=$this->input->post('total_biaya');
			
			$data = array('total_biaya' => $biaya
			 );
			$this->klaim_model->update_second_klaim($data,$id_biaya);
			
			$data['error']="Berhasil Di update";
			$data['title']="Edit Biaya";
			$data['klaim']=$this->klaim_model->get_biaya_by_id($id)->row();

			$this->load->view('dinkes/bg_atas',$data);
			$this->load->view('dinkes/bg_menu',$data);
			$this->load->view('dinkes/klaim/v_edit_biaya',$data);
			$this->load->view('dinkes/bg_bawah',$data);
		}
	}
}//end of controller