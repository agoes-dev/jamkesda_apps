<?php  defined('BASEPATH') OR exit('No direct script access allowed');
/**
* Author : AgusPunya
*/
class Login extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model(array('user_model'));
		$this->load->helper(array('url','form','html'));
	}
	function index(){
		$data['error']="";
		$data['title']="E-JAMKESDA | Jaminan Kesehatan Daerah Online";

		$this->load->view('bg_atas',$data);
		$this->load->view('v_login_app',$data);
		$this->load->view('bg_bawah',$data);
	}
	function action(){
		$userID = $this->input->post('userid',TRUE);
		$password = $this->input->post('password',TRUE);
		$log_as = $this->input->post('level',TRUE);

		if($log_as == 'dinkes'){
			$data=array(
				'id_user'=>$userID,
				'password'=>md5($password)
			);
			$cekUser=$this->user_model->cek_user($data)->num_rows();
			
			if($cekUser > 0){
				$data=$this->user_model->cek_user($data)->row();
				if($data->level == 'petugas'){
					$sess_data = array(
					'username' => $data->nm_user,
					'id_user' => $data->id_user,
					'level' => $data->level
					);
					$this->session->set_userdata($sess_data);
					redirect('dinkes');
				}else{
					$sess_data = array(
					'username' => $data->nm_user,
					'id_user' => $data->id_user,
					'level' => $data->level
					);
					$this->session->set_userdata($sess_data);
					redirect('kabid');
				}	
				
			}else{
				$data['error']="Wrong UserID or Password!";
				$data['title']="E-JAMKESDA | Jaminan Kesehatan Daerah Online";

				$this->load->view('bg_atas',$data);
				$this->load->view('v_login_app',$data);
				$this->load->view('bg_bawah',$data);
			}

		}else if($log_as == 'hospital'){
			$data=array(
				'id_hospital'=>$userID,
				'password'=>md5($password)
				);
				$cek_user=$this->user_model->cek_data($data)->num_rows();
				
				if($cek_user > 0){
					$data=$this->user_model->cek_data($data)->row();

					$sess_data = array(
						'username' => $data->nm_hospital,
						'id_user' => $data->id_hospital,
						'level' =>'hospital' 
						);
					$this->session->set_userdata($sess_data);
					redirect('hospital');	
				}else{
					$data['error']="Wrong Username or Password!";
					$data['title']="E-JAMKESDA | Jaminan Kesehatan Daerah Online";

					$this->load->view('bg_atas',$data);
					$this->load->view('v_login_app',$data);
					$this->load->view('bg_bawah',$data);
				}
		}else{
			$data['error']="Wrong Username or Password!";
			$data['title']="E-JAMKESDA | Jaminan Kesehatan Daerah Online";

			$this->load->view('bg_atas',$data);
			$this->load->view('v_login_app',$data);
			$this->load->view('bg_bawah',$data);
			}
		}
}//end of controller