<?php 
/**
* 
*/
class Logout extends Ci_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','form'));
	}
    function index(){
    	

		$this->session->unset_userdata(array('username','level'));
		$this->session->sess_destroy(array('username','level'));
		//$data['error']="You Are Logged Out";
		//$data['title']="Sistem Informasi Pemberian Bantuan Jaminan";
		$this->session->sess_destroy();
		redirect('login');
		//$this->load->view('v_login',$data);
	}
}//end of controller