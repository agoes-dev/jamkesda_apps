<?php

/**
* Author : Agus
*/
class Kabid_model extends CI_Model
{
	function get_all_peserta(){
		$this->db->select("tbl_jaminan.no_jaminan,tbl_jaminan.nm_peserta,tbl_jaminan.jk,tbl_kecamatan.kecamatan,tbl_desa.desa,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_jaminan.nik_peserta,tbl_jaminan.status_kawin,tbl_jaminan.diagnosis,tbl_jaminan.alamat,tbl_jaminan.rt,tbl_jaminan.rw,tbl_jaminan.tmp_lahir,tbl_jaminan.tgl_lahir,tbl_jaminan.skkm_dinsos");
		$this->db->from('tbl_jaminan');
		$this->db->where('YEAR(tgl_permohonan)',date('Y'));
		$this->db->join('tbl_kecamatan','tbl_kecamatan.id_kecamatan = tbl_jaminan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_desa.id_desa = tbl_jaminan.id_desa');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_jaminan.id_hospital');
		$this->db->order_by('no_jaminan','DESC');
		return $this->db->get();
	}
	function get_all_biaya(){
		$this->db->select("tbl_jaminan.nm_peserta,tbl_biaya.no_jaminan,tbl_hospital.nm_hospital,tbl_biaya.tgl_selesai,tbl_biaya.total_biaya,tbl_biaya.kwitansi");
		$this->db->from('tbl_biaya');
		$this->db->join('tbl_jaminan','tbl_jaminan.no_jaminan = tbl_biaya.no_jaminan');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_biaya.id_hospital');
		$this->db->order_by('id_biaya','ASC');
		return $this->db->get();
	}
	function get_grand_total(){
		$this->db->select_sum('total_biaya');
		$this->db->from('tbl_biaya');
		return ($this->db->get());
	}
	function get_data_peserta(){
		$this->db->select("tbl_jaminan.no_jaminan,tbl_jaminan.nm_peserta,tbl_jaminan.jk,tbl_kecamatan.kecamatan,tbl_desa.desa,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_jaminan.nik_peserta,tbl_jaminan.status_kawin,tbl_jaminan.diagnosis,tbl_jaminan.alamat,tbl_jaminan.rt,tbl_jaminan.rw,tbl_jaminan.tmp_lahir,tbl_jaminan.tgl_lahir,tbl_jaminan.skkm_dinsos");
		$this->db->where('MONTH(tgl_permohonan)',date('m'));
		$this->db->join('tbl_kecamatan','tbl_kecamatan.id_kecamatan = tbl_jaminan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_desa.id_desa = tbl_jaminan.id_desa');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_jaminan.id_hospital');
		return $this->db->get('tbl_jaminan');
	}
	function get_dirawat(){
		$this->db->where('status','new');
		return $this->db->get('tbl_jaminan');
	}
}// end of models