<?php 
class Hospital_model extends CI_Model
{
	function get_username($id){
		//$this->db->where('id_user',$id)
		$this->db->where('id_user',$id);
		return($this->db->get('tbl_user'));
	}	
	function get_new_jaminan($id){
		$this->db->where('id_hospital',$id);
		$this->db->where('status','new');
		return($this->db->get('tbl_jaminan'));
	}
	function getJaminan($id){
		$this->db->where('id_hospital',$id);
		$this->db->where('status','new');
		$this->db->order_by('no_jaminan','DESC');
		return($this->db->get('tbl_jaminan'));
	}
	function getDetailJaminan($id,$id_user){
		$this->db->like('no_jaminan',$id);
		$this->db->where('id_hospital',$id_user);
		return($this->db->get('tbl_jaminan'));
		//$sql = $this->db->query("SELECT * FROM tbl_jaminan where id_hospital = '$id_user' AND no_jaminan = '$id'");
		//return $sql;
	}
	function save_biaya($biaya){
		$this->db->insert('tbl_biaya',$biaya);
	}
	function get_data_perawatan($id){
		$this->db->select('tbl_biaya.id_biaya,tbl_jaminan.nik_peserta,tbl_biaya.no_jaminan,tbl_jaminan.nm_peserta,tbl_jaminan.tgl_permohonan,tbl_biaya.tgl_selesai,tbl_biaya.kwitansi,tbl_biaya.status');
		$this->db->where('tbl_biaya.id_hospital',$id);
		$this->db->join('tbl_jaminan','tbl_jaminan.no_jaminan = tbl_biaya.no_jaminan');
		$this->db->order_by('tbl_biaya.id_biaya','DESC');
		return $this->db->get('tbl_biaya');
	}
	function updateStatusJaminan($jaminan,$no_jaminan){
		$this->db->where('no_jaminan',$no_jaminan);
		$this->db->update('tbl_jaminan',$jaminan);
	}
	function get_peserta_by_id($id){
		$this->db->where('id_biaya',$id);
		return $this->db->get('tbl_biaya');
	}
	function update_klaim($data,$id){
		$this->db->where('id_biaya',$id);
		$this->db->update('tbl_biaya',$data);
	}
}//end of models