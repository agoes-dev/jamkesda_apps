<?php 
class User_model extends CI_Model
{
	function cek_user($data){
		return $this->db->get_where('tbl_dinkes',$data);
	}
	function cek_petugas_dinkes($data){
		return $this->db->get_where('tbl_dinkes',$data);
	}
	//hospital
	function cek_data($data){
		return $this->db->get_where('tbl_hospital',$data);
	}
	function getUser($id_user){
		$this->db->where('id_user',$id_user);
		return $this->db->get('tbl_user');
	}
	function get_all_user(){
		return $this->db->get('tbl_dinkes');
	}
	function saveUser($user){
		$this->db->insert('tbl_dinkes',$user);
	}
	function get_user_by_id($id){
		$this->db->where('id',$id);
		return $this->db->get('tbl_dinkes');
	}
	function updateUser($user,$id){
		$this->db->where('id',$id);
		$this->db->update('tbl_dinkes',$user);
	}
	function del_by_id($id){
		$this->db->where('id',$id);
		$this->db->delete('tbl_dinkes');
	}
}//end of models