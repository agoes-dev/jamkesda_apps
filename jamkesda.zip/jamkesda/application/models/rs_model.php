<?php
class Rs_model extends CI_Model
{
	function getUser($id_user){
		$this->db->where('id_user',$id_user);
		return($this->db->get('tbl_user'));
	}
	function get_all_hospital(){
		return $this->db->get('tbl_hospital');
	}
	function cekIdHospital($id){
		$this->db->where('id_hospital',$id);
		return($this->db->get('tbl_hospital'));
	}
	function saveHospital($hospital){
		$this->db->insert('tbl_hospital',$hospital);
	}
	function delHospital($id){
		$this->db->where('id_hospital',$id);
		$this->db->delete('tbl_hospital');
	}
	function getName($id){
		$this->db->where('id_hospital',$id);
		return($this->db->get('tbl_hospital'));
	}
	function get_last_number(){
		$this->db->select('id_hospital');
		$this->db->from('tbl_hospital');
		$this->db->order_by('id_hospital','DESC');
		return($this->db->get());
	}
	function updateHospital($hospital,$id_hospital){
		$this->db->where('id_hospital',$id_hospital);
		$this->db->update('tbl_hospital',$hospital);
	}
}