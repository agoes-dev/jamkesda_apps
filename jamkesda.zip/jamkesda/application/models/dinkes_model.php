<?php
class Dinkes_model extends CI_Model
{
	//get name user
	function getUser($id_user){
		$this->db->where('id_user',$id_user);
		return($this->db->get('tbl_user'));
	}
	function save_jaminan($jaminan){
		$this->db->insert('tbl_jaminan',$jaminan);
	}
	function save_pasien($pasien){
		$this->db->insert('tbl_pasien',$pasien);
	}
	function get_all_jaminan(){
		$this->db->select("tbl_jaminan.no_jaminan,tbl_jaminan.nm_peserta,tbl_jaminan.jk,tbl_kecamatan.kecamatan,tbl_desa.desa,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_jaminan.nik_peserta,tbl_jaminan.status_kawin,tbl_jaminan.diagnosis,tbl_jaminan.alamat,tbl_jaminan.rt,tbl_jaminan.rw,tbl_jaminan.tmp_lahir,tbl_jaminan.tgl_lahir,tbl_jaminan.skkm_dinsos");
		$this->db->from('tbl_jaminan');
		$this->db->join('tbl_kecamatan','tbl_kecamatan.id_kecamatan = tbl_jaminan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_desa.id_desa = tbl_jaminan.id_desa');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_jaminan.id_hospital');
		$this->db->order_by('no_jaminan','DESC');
		return $this->db->get();
	}
	function get_jaminan_rawat(){
		$this->db->select("tbl_jaminan.no_jaminan,tbl_jaminan.nm_peserta,tbl_jaminan.jk,tbl_kecamatan.kecamatan,tbl_desa.desa,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_jaminan.nik_peserta,tbl_jaminan.status_kawin,tbl_jaminan.diagnosis,tbl_jaminan.alamat,tbl_jaminan.rt,tbl_jaminan.rw,tbl_jaminan.tmp_lahir,tbl_jaminan.tgl_lahir,tbl_jaminan.skkm_dinsos");
		$this->db->where('tbl_jaminan.status','new');
		$this->db->from('tbl_jaminan');
		$this->db->join('tbl_kecamatan','tbl_kecamatan.id_kecamatan = tbl_jaminan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_desa.id_desa = tbl_jaminan.id_desa');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_jaminan.id_hospital');
		$this->db->order_by('no_jaminan','DESC');
		return $this->db->get();
	}
	function get_last_number(){
		$this->db->select('no_jaminan');
		$this->db->from('tbl_jaminan');
		$this->db->order_by('no_jaminan','DESC');
		return($this->db->get());
	}
	function get_data($id){
		//$this->db->query("SELECT * FROM `tbl_jaminan` WHERE `no_jaminan` LIKE '%$id%' ");
		//return $this->db->get('tbl_jaminan');
		$this->db->select('no_jaminan,nm_pasien,tgl_permohonan,nik_pasien,status,tbl_kecamatan.kecamatan,tbl_desa.desa,alamat_pasien,tbl_hospital.nm_hospital,tmp_lahir,tgl_lahir,rt,rw,skkm_dinsos,skkm_kepala_desa,diagnosis');
		$this->db->join('tbl_kecamatan','tbl_kecamatan.id_kecamatan = tbl_jaminan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_desa.id_desa = tbl_jaminan.id_desa');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_jaminan.id_hospital');
		//$this->db->where('no_jaminan');
		$this->db->like('no_jaminan',$id);
		$this->db->from('tbl_jaminan');
		return($this->db->get());
	}
	function get_kec_list(){
		$result = array();
		$this->db->select('*');
		$this->db->from('tbl_kecamatan');
		$this->db->order_by('kecamatan','ASC');
		$array_keys_values = $this->db->get();
		foreach ($array_keys_values->result() as $row) {
			$result['']='Pilih Kecamatan';
			$result[$row->id_kecamatan]=$row->kecamatan;
		}
		return $result;
	}
	function get_desa_list(){
		$kec_id=$this->input->post('kecamatan_id');
		$result = array();
		$this->db->select('*');
		$this->db->from('tbl_desa');
		$this->db->where('id_kecamatan',$kec_id);
		$this->db->order_by('desa','ASC');
		$array_keys_values = $this->db->get();
		foreach ($array_keys_values->result() as $row) {
			$result['']='Pilih Desa/Kelurahan';
			$result[$row->id_desa]=$row->desa;
		}
		return $result;
	}
	function get_rs_list(){
		$result = array();
		$this->db->select('*');
		$this->db->from('tbl_hospital');
		$this->db->where('status','1');
		$this->db->order_by('nm_hospital','ASC');
		$array_keys_values = $this->db->get();
		foreach ($array_keys_values->result() as $row) {
			$result['']='Pilih Rumah Sakit';
			$result[$row->id_hospital]=$row->nm_hospital;
		}
		return $result;
	}
	function get_all_biaya(){
		return $this->db->get('tbl_biaya');
	}
	function edit_jaminan_by_id($id){
		$this->db->select('tbl_jaminan.no_jaminan,tbl_jaminan.id_hospital,tbl_jaminan.nm_peserta,tbl_jaminan.tmp_lahir,tbl_jaminan.tgl_lahir,tbl_jaminan.alamat,tbl_jaminan.rt,tbl_jaminan.rw,tbl_jaminan.diagnosis,tbl_jaminan.skkm_dinsos,tbl_jaminan.nik_peserta,tbl_jaminan.jk,tbl_jaminan.status_kawin,tbl_kecamatan.kecamatan,tbl_desa.desa,tbl_hospital.nm_hospital,tbl_jaminan.id_kecamatan,tbl_jaminan.id_desa');
		$this->db->like('tbl_jaminan.no_jaminan',$id);
		$this->db->join('tbl_kecamatan','tbl_jaminan.id_kecamatan = tbl_kecamatan.id_kecamatan');
		$this->db->join('tbl_desa','tbl_jaminan.id_desa = tbl_desa.id_desa');
		$this->db->join('tbl_hospital','tbl_jaminan.id_hospital = tbl_hospital.id_hospital');
		//$this->db->from('tbl_jaminan');
		return $this->db->get('tbl_jaminan');
	}
	function get_data_klaim(){
		$this->db->where('status','new');
		return $this->db->get('tbl_biaya');
	}
	function get_data_peserta(){
		return $this->db->get('tbl_jaminan');
	}
	function get_data_rawat(){
		$this->db->where('status','new');
		return $this->db->get('tbl_jaminan');
	}
	function get_data_hospital(){
		return $this->db->get('tbl_hospital');
	}
	function update_jaminan($jaminan,$no_jaminan){
		$this->db->like('no_jaminan',$no_jaminan);
		$this->db->update('tbl_jaminan',$jaminan);
	}
}//end of models