<?php
/**
* 
*/
class Chart_model extends CI_Model
{
	function reportJaminan(){
		$year=date('Y');
		$sql = $this->db->query("
   
  select
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=1)AND (YEAR(tgl_permohonan)=$year))),0) AS `Januari`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=2)AND (YEAR(tgl_permohonan)=$year))),0) AS `Februari`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=3)AND (YEAR(tgl_permohonan)=$year))),0) AS `Maret`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=4)AND (YEAR(tgl_permohonan)=$year))),0) AS `April`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=5)AND (YEAR(tgl_permohonan)=$year))),0) AS `Mei`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=6)AND (YEAR(tgl_permohonan)=$year))),0) AS `Juni`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=7)AND (YEAR(tgl_permohonan)=$year))),0) AS `Juli`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=8)AND (YEAR(tgl_permohonan)=$year))),0) AS `Agustus`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=9)AND (YEAR(tgl_permohonan)=$year))),0) AS `September`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=10)AND (YEAR(tgl_permohonan)=$year))),0) AS `Oktober`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=11)AND (YEAR(tgl_permohonan)=$year))),0) AS `November`,
  ifnull((SELECT count(no_jaminan) FROM (tbl_jaminan)WHERE((Month(tgl_permohonan)=12)AND (YEAR(tgl_permohonan)=$year))),0) AS `Desember`
 from tbl_jaminan GROUP BY YEAR(tgl_permohonan) 
   
  ");
   
  return $sql;
	}
  function report_biaya1(){
    $sql = $this->db->query("SELECT * FROM tbl_biaya where total_biaya < 1000000");

    return $sql;
  }
  function report_biaya2(){
    $sql = $this->db->query("SELECT * FROM tbl_biaya where total_biaya between 1000000 AND 5000000");

    return $sql;
  }
  function report_biaya3(){
    $sql = $this->db->query("SELECT * FROM tbl_biaya where total_biaya > 5000000");

    return $sql;
  }
  function get_data_by_male(){
    $this->db->where('jk','1');
    return $this->db->get('tbl_jaminan');
  }
  function get_data_by_female(){
    $this->db->where('jk','2');
    return $this->db->get('tbl_jaminan'); 
  }
}