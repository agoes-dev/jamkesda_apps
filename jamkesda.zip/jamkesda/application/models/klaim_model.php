<?php
/**
* author by Agus Punya
*/
class Klaim_model extends CI_Model
{
	function get_all_klaim_by_status(){
		$this->db->select('tbl_biaya.id_biaya,tbl_biaya.id_hospital,tbl_biaya.no_jaminan,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_biaya.tgl_selesai,tbl_biaya.status,tbl_biaya.total_biaya,tbl_biaya.kwitansi');
		$this->db->from('tbl_biaya');
		$this->db->where('tbl_biaya.status','claimed');
		$this->db->order_by('tbl_biaya.id_biaya','DESC');
		$this->db->join('tbl_jaminan','tbl_jaminan.no_jaminan = tbl_biaya.no_jaminan');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_biaya.id_hospital');
		return($this->db->get());
	}
	function get_klaim_by_id(){
		$this->db->select('tbl_biaya.id_biaya,tbl_biaya.id_hospital,tbl_biaya.no_jaminan,tbl_hospital.nm_hospital,tbl_jaminan.tgl_permohonan,tbl_biaya.tgl_selesai,tbl_biaya.status');
		$this->db->from('tbl_biaya');
		$this->db->where('tbl_biaya.status','new');
		$this->db->join('tbl_jaminan','tbl_jaminan.no_jaminan = tbl_biaya.no_jaminan');
		$this->db->join('tbl_hospital','tbl_hospital.id_hospital = tbl_biaya.id_hospital');
		return($this->db->get());	
	}
	function get_data_by_id($id){
		$this->db->where('id_biaya',$id);
		return $this->db->get('tbl_biaya');
	}
	//update biaya yang diklaim RS
	function update_klaim($update,$id_biaya){
		$this->db->where('id_biaya',$id_biaya);
		$this->db->update('tbl_biaya',$update);
	}

	function get_biaya_by_id($id){
		$this->db->where('id_biaya',$id);
		return($this->db->get('tbl_biaya'));
	}
	function update_second_klaim($data,$id_biaya){
		$this->db->where('id_biaya',$id_biaya);
		$this->db->update('tbl_biaya',$data);
	}

}//end of models